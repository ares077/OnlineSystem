package MyFiveGame;

import java.util.Random;

public class Method {
	int wincount =5;
	int posX=0;
	int posY=0;
	public void computerdo(String[][] board)
	{
		while(true)
		{
			Random r=new Random();
			this.posX=r.nextInt(15);
			this.posY=r.nextInt(15);
			if(board[posX][posY]!="ʮ")
			{
				continue;
			}
			else
			{
				board[posX][posY]="��";
				break;
			}
		}
		
	}
	public void initchessboard(String[][] board)
	{
		for (int i = 0 ; i < 15 ; i++)
		{
			for ( int j = 0 ; j < 15 ; j++)
			{
				board[i][j] = "ʮ";
			}
		}
	}
	public boolean isexist(String[][] board,int x,int y)
	{
		try{
			if(board[x][y]!="ʮ")
			{
				return false;
			}
			return true;
		}catch(ArrayIndexOutOfBoundsException ee)
		{
			return true;
		}
			
	}
	public boolean iswin(String[][] board,String a,int cbx,int cby)
	{
		//ֱ������X ����
		int startX = 0;
		//ֱ�����Y ����
		int startY = 0;
		int startYY=0;
		//ֱ�߽���X ����
		int endX = 14;
		//ֱ�߽���Y ����
		int endY = 14;
		int endYY =0;
		//ͬ��ֱ�������������ۻ���
		int sameCountx = 0;
		int sameCounty = 0;
		int sameCountxx = 0;
		int sameCountyy = 0;
		int temp = 0;
		//����������СX ������Y ����
		temp = cbx - 4;
		startX = temp < 0 ? 0 : temp;
		temp = cby - 4;
		startY = temp < 0 ? 0 : temp;
		startYY=startY;
		//б�����ʼ��СXY����

		//�����յ�����X ������Y ����
		temp = cbx + 4;
		endX = temp > 14 ?14 : temp;
		temp = cby + 4;
		endY = temp > 14 ?14 : temp;
		endYY=endY;
		//�����ҷ��������ͬ�������ӵ���Ŀ
		for( int i = startY; i < endY; i++)
		{
		     if( board[cbx][i].equals(a) && board[cbx][i+1] .equals(a) )
		         {
		             sameCounty++;
		             if(sameCounty==4)
		             {
		            	 return true;
		             }
		         }
		     else 
		         {
				     sameCounty = 0;
		         }
		}
		for( int i=startX;i<endX;i++)
		{
		     if( board[i][endYY].equals( a) && board[i+1][endYY-1].equals(a) )
		         {
		             sameCountyy++;
		             if(sameCountyy==4)
		             {
		            	 return true;
		             }
		         }
		     else 
		         {
				     sameCountyy = 0;
		         }
		     endYY--;
		     if(endYY==0)
				{
					break;
				}
		}
		for(int i=startX;i<endX;i++)
		{
			if(board[i][cby].equals(a) && board[i+1][cby].equals(a))
			{
				sameCountx++;
				if(sameCountx==4)
				{
					return true;
				}
			}
			else
				{
					sameCountx=0;
				}
		}
		for(int i=startX;i<endX;i++)
		{
			if(board[i][startYY].equals(a) && board[i+1][startYY+1].equals(a))
			{
				sameCountxx++;
				if(sameCountxx==4)
				{
					return true;
				}
			}
			else
				{
					sameCountxx=0;
				}
			startYY++;
			if(startYY==14)
			{
				break;
			}
		}
		return false;
			
	}

}
