package MyMIS;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;

public class DataBaseIO {
	Connection conn;
	public DataBaseIO()
	{
		isConnected();
	}
	//�������ݿ�
	public boolean isConnected()
	{
		String url="jdbc:mysql://localhost:3306/mystudent?user=root&password=123456";
		try{
			Class.forName("org.gjt.mm.mysql.Driver");
		    conn=(Connection) DriverManager.getConnection(url);
		return true;			
		}catch(SQLException e)
		{
			System.out.println(e.getMessage());
			return false;
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
			return false;
		}
	}
	//�ر����ݿ�
	public void connClose() throws SQLException
	{
		this.conn.close();
	}
	//�Ƿ�ע��������ڱ����ҵ���Ӧ���û��������룿
	public boolean isRegister(String rtablename,String rid,String rpw)
	{					
			try{
				PreparedStatement ps=(PreparedStatement) conn.prepareStatement("select * from student where studentid=? and studentpw=?");
				if(rtablename=="admin")
				{
					 ps=(PreparedStatement) conn.prepareStatement("select * from admin where adminid=? and adminpw=?");		
				}
                if(rtablename=="teacher")
				{
					 ps=(PreparedStatement) conn.prepareStatement("select * from teacher where teacherid=? and teacherpw=?");
				}				
				ps.setString(1, rid);
				ps.setString(2, rpw);
				ResultSet rs=ps.executeQuery();
				if(rs.next())
				{
					return true;
				}
			}catch(SQLException e)
			{
				return false;
			}catch(Exception e)
			{
				return false;
			}
			return false;
	}
	//�Ƿ�ɹ��޸�������
	public boolean isalterpassword(String altablename,String alid,String alpw,String alrepw) throws SQLException
	{
		if(this.isRegister(altablename, alid, alpw))
		{
			PreparedStatement ps=(PreparedStatement) conn.prepareStatement("update student set studentpw=? where studentid=?");
			if(altablename=="teacher")
			{
				ps=(PreparedStatement) conn.prepareStatement("update teacher set teacherpw=? where teacherid=?");	
			}
			ps.setString(1, alrepw);
			ps.setString(2, alid);
			int rs=ps.executeUpdate();
			if(rs==1)
			{
				return true;
			}
			return false;
		}
		return false;
	}
	//����Ա�Ƿ�ɹ��޸�������
	public boolean isadminalterpw(String mltablename,String mlid,String mlpw) throws SQLException
	{
		PreparedStatement ps=(PreparedStatement) conn.prepareStatement("update student set studentpw=? where studentid=?");
		if(mltablename=="teacher")
		{
			ps=(PreparedStatement) conn.prepareStatement("update teacher set teacherpw=? where teacherid=?");	
		}
		ps.setString(1, mlpw);
		ps.setString(2, mlid);
		int rs=ps.executeUpdate();
		if(rs==1)
		{
			return true;
		}
		return false;
	}
	//�Ƿ�ɹ����������û�
	public boolean isaddnewcustom(String actablename,String acid,String acpw,String acname,String acmail,String acphonum) throws SQLException
	{
		PreparedStatement ps=(PreparedStatement) conn.prepareStatement("insert into student values(?,?,?,?,?)");
		if(actablename=="teacher")
		{
			ps=(PreparedStatement) conn.prepareStatement("insert into teacher values(?,?,?,?,?)");	
		}
		ps.setString(1, acid);
		ps.setString(2, acpw);
		ps.setString(3, acname);
		ps.setString(4, acmail);
		ps.setString(5, acphonum);
		int rs=ps.executeUpdate();
		if(rs==1)
		{
			return true;
		}
		return false;	
	}
	//�Ƿ����ӳɹ� �¿γ�
	public boolean isaddnewcourse(String aoid,String aoname,String aoadress,String aointro,String aoview) throws SQLException
	{
		PreparedStatement ps=(PreparedStatement) conn.prepareStatement("insert into course values(?,?,?,?,?)");
		ps.setString(1, aoid);
		ps.setString(2, aoname);
		ps.setString(3, aoadress);
		ps.setString(4, aointro);
		ps.setString(5, aoview);
		int rs=ps.executeUpdate();
		if(rs==1)
		{
			return true;
		}
		return false;
		
	}
	//�Ƿ��޸��˿γ�
	public boolean isaltercourse(String alcstr1,String alcid,String alcnai) throws SQLException
	{
		PreparedStatement ps=(PreparedStatement) conn.prepareStatement("update course set courseaview=? where courseid=?");
		if(alcstr1=="coursename")
		{
			 ps=(PreparedStatement) conn.prepareStatement("update course set coursename=? where courseid=?");
		}
		if(alcstr1=="courseadress")
		{
			ps=(PreparedStatement) conn.prepareStatement("update course set courseadress=? where courseid=?");
		}
		if(alcstr1=="courseintro")
		{
			ps=(PreparedStatement) conn.prepareStatement("update course set courseintro=? where courseid=?");
		}
		ps.setString(1, alcnai);
		ps.setString(2, alcid);
		int rs=ps.executeUpdate();
		if(rs==1)
		{
			return true;
		}
		return false;
	}
	//���ز�ѯ����ġ��γ̵ġ�ѧ���ģ���ʦ�� ������ϢResultSet.
	public ResultSet selectall(String satablename) throws SQLException
	{
		/*PreparedStatement ps=(PreparedStatement) conn.prepareStatement("select * from ?");
		ps.setString(1,tablename);
		ResultSet rs=ps.executeQuery();*/
		ResultSet rs;
		Statement sta=(Statement) conn.createStatement();
		if(satablename=="student")
		{
			rs=sta.executeQuery("select * from student");
		}
		else if(satablename=="course")
		{
			rs=sta.executeQuery("select * from course");		
		}
		else
		{
			rs=sta.executeQuery("select * from teacher");
		}
		return rs;
	}
	//���ز�ѯ����ġ��γ̵ġ�ѧ���ģ���ʦ�� ������ϢResultSet.
	public ResultSet selectone(String otablename,String oid) throws SQLException
	{
		/*PreparedStatement ps=(PreparedStatement) conn.prepareStatement("select * from ?");
		ps.setString(1,tablename);
		ResultSet rs=ps.executeQuery();*/
		ResultSet rs;
		PreparedStatement ps=(PreparedStatement) conn.prepareStatement("select * from student where studentid=?");
	    if(otablename=="course")
		{
	    	ps=(PreparedStatement) conn.prepareStatement("select * from course where courseid=?");	
		}
		else if(otablename=="teacher")
		{
			ps=(PreparedStatement) conn.prepareStatement("select * from teacher where teacherid=?");
		}
	    ps.setString(1, oid);
		rs=ps.executeQuery();
		return rs;
	}
	public ResultSet selectone(String otablename,int oid) throws SQLException
	{
		ResultSet rs;
		PreparedStatement ps=(PreparedStatement) conn.prepareStatement("select * from student where studentid=?");
	    if(otablename=="course")
		{
	    	ps=(PreparedStatement) conn.prepareStatement("select * from course where courseid=?");	
		}
		else if(otablename=="teacher")
		{
			ps=(PreparedStatement) conn.prepareStatement("select * from teacher where teacherid=?");
		}
	    ps.setInt(1, oid);
		rs=ps.executeQuery();
		return rs;
	}
	//�޸ĵ�����ʦ��Ϣ
	public boolean isalterteacherinfo(int atiid,String atipw,String atiname,String atimail,String atinum) throws SQLException
	{
		PreparedStatement ps=(PreparedStatement) conn.prepareStatement("update teacher set teacherpw=?,teachername=?,teachermail=?,teacherphonum=? where teacherid=?");
		ps.setString(1, atipw);
		ps.setString(2, atiname);
		ps.setString(3, atimail);
		ps.setString(4, atinum);
		ps.setInt(5, atiid);
		int rs=ps.executeUpdate();
		if(rs==1)
		{
			return true;
		}
		return false;
	}
	//���ؽ�ʦѡ����Ϣ
	public ResultSet returnallteacherscourseinfo(int tscid) throws SQLException
	{
		PreparedStatement ps=(PreparedStatement) conn.prepareStatement("SELECT course.courseid,course.coursename,teacherlevel from teacherselect,course where teacherselect.courseid=course.courseid and teacherselect.teacherid=?");
		ps.setInt(1, tscid);
		ResultSet rs=ps.executeQuery();
		return rs;
	}
	//�Ƿ�������еĽ�ʦ���γ̣�ѧ��
	public boolean isexitteacoursestu(String tcstablename,String tcsid) throws SQLException
	{
		PreparedStatement ps=(PreparedStatement) conn.prepareStatement("select * from student where studentid=?");
		if(tcstablename=="teacher")
		{
			ps=(PreparedStatement) conn.prepareStatement("select * from teacher where teacherid=?");
		}
		if(tcstablename=="course")
		{
			ps=(PreparedStatement) conn.prepareStatement("select * from course where courseid=?");
		}
		ps.setString(1, tcsid);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
		{
			return true;
		}
		return false;
	}
    //�Ƿ�̻�ѡ�Ͽ���
	public boolean isteacherselectcourse(String itscid,int itsctic) throws SQLException
	{
		PreparedStatement ps=(PreparedStatement) conn.prepareStatement("insert into teacherselect(courseid,teacherid) values(?,?)");
		ps.setString(1, itscid);
		ps.setInt(2, itsctic);
		int rs=ps.executeUpdate();
		if(rs==1)
		{
			return true;
		}
		return false;
	}
	//�Ƿ�ɾ����ѡ����Ϣ
	public boolean isdelectteacherselectcourse(String idtscid,int idtsctid) throws SQLException
	{
		PreparedStatement ps=(PreparedStatement) conn.prepareStatement("delete from teacherselect where courseid=? and teacherid=?");
		ps.setString(1, idtscid);
		ps.setInt(2, idtsctid);
		int rs=ps.executeUpdate();
		if(rs==1)
		{
			return true;
		}
		return false;
	}
    //�Ƿ��Ѿ����ڽ�ʦѡ����Ϣ��
	public boolean isexitedteacherselectcourse(String ietscid,int ietsctid) throws SQLException
	{
		PreparedStatement ps=(PreparedStatement) conn.prepareStatement("select * from teacherselect where courseid=? and teacherid=?");
		ps.setString(1, ietscid);
		ps.setInt(2, ietsctid);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
		{
			return true;
		}
		return false;
	}
    //���ص�����ʦѡ�α���Ϣ
	public ResultSet returnoneteqacherselectcourse(int retscid) throws SQLException
	{
		PreparedStatement ps=(PreparedStatement) conn.prepareStatement("select course.courseid,coursename,courseaview from course,teacherselect where course.courseid=teacherselect.courseid and teacherid=?");
		ps.setInt(1, retscid);
		ResultSet rs=ps.executeQuery();
		return rs;
	}
	 //���ص���ѧ��ѡ�α���Ϣ
		public ResultSet returnonestudentselectcourse(int resscid) throws SQLException
		{
			PreparedStatement ps=(PreparedStatement) conn.prepareStatement("select course.courseid,coursename,studentgrade,coursesturemark from course,studentselect where course.courseid=studentselect.courseid and studentid=?");
			ps.setInt(1, resscid);
			ResultSet rs=ps.executeQuery();
			return rs;
		}
	//�޸ĵ���ѧ����Ϣ
		public boolean isalterstudentinfo(int asiid,String asipw,String asiname,String asimail,String asinum) throws SQLException
		{
			PreparedStatement ps=(PreparedStatement) conn.prepareStatement("update student set studentpw=?,studentname=?,studentmail=?,studentphonum=? where studentid=?");
			ps.setString(1, asipw);
			ps.setString(2, asiname);
			ps.setString(3, asimail);
			ps.setString(4, asinum);
			ps.setInt(5, asiid);
			int rs=ps.executeUpdate();
			if(rs==1)
			{
				return true;
			}
			return false;
		}
	//�������пγ���Ϣ������ʦ��
		public ResultSet returencoursewithtacher() throws SQLException
		{
			Statement sta=(Statement) conn.createStatement();
			ResultSet rs=sta.executeQuery("select teacherselect.courseid,coursename,courseadress,courseintro,teachername,teacherlevel,courseaview from teacher,course,teacherselect where teacher.teacherid=teacherselect.teacherid and teacherselect.courseid=course.courseid ");
			return rs;
		}
		//����ѧ���Ѿ�ѡ��Ŀγ�
		public ResultSet returnstudentalreadyselectcourse(int rslsid) throws SQLException
		{
			PreparedStatement ps=(PreparedStatement) conn.prepareStatement("select teacherselect.courseid,coursename,courseadress,courseintro,teachername from course,teacher,studentselect,teacherselect where course.courseid=studentselect.courseid and teacher.teacherid=teacherselect.teacherid and teacherselect.courseid=studentselect.courseid and studentid=?");
		    ps.setInt(1, rslsid);
		    ResultSet rs=ps.executeQuery();
		    return rs;
		}
		//�Ƿ���ڵĽ�ʦѡ���Ŀγ�
		public boolean isexitedteacherselectcoursecanbestuident(String ietscidctid) throws SQLException
		{
			PreparedStatement ps=(PreparedStatement) conn.prepareStatement("select * from teacherselect where courseid=?");
			ps.setString(1, ietscidctid);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				return true;
			}
			return false;
		}
		 //�Ƿ��Ѿ�����ѧ��ѡ����Ϣ��
		public boolean isexisturselectcourse(String ssietscid,int ssietsctid) throws SQLException
		{
			PreparedStatement ps=(PreparedStatement) conn.prepareStatement("select * from studentselect where courseid=? and studentid=?");
			ps.setString(1, ssietscid);
			ps.setInt(2, ssietsctid);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				return true;
			}
			return false;
		}
		  //�Ƿ�ѧ��ѡ�Ͽ���
		public boolean isstuselectcourse(String ssitscid,int ssitsctic) throws SQLException
		{
			PreparedStatement ps=(PreparedStatement) conn.prepareStatement("insert into studentselect(courseid,studentid) values(?,?)");
			ps.setString(1, ssitscid);
			ps.setInt(2, ssitsctic);
			int rs=ps.executeUpdate();
			if(rs==1)
			{
				return true;
			}
			return false;
		}
		//�Ƿ�ɾ����ѧ��ѡ����Ϣ
		public boolean isdelectstuselectcourse(String ssidtscid,int ssidtsctid) throws SQLException
		{
			PreparedStatement ps=(PreparedStatement) conn.prepareStatement("delete from studentselect where courseid=? and studentid=?");
			ps.setString(1, ssidtscid);
			ps.setInt(2, ssidtsctid);
			int rs=ps.executeUpdate();
			if(rs==1)
			{
				return true;
			}
			return false;
		}
		//����ѧ���ɼ�
		public ResultSet returnstudentnote1111111(int sssrslsid) throws SQLException
		{
			PreparedStatement ps=(PreparedStatement) conn.prepareStatement("select course.courseid,coursename,studentgrade from studentselect,course where course.courseid=studentselect.courseid and studentid=?");
		    ps.setInt(1, sssrslsid);
		    ResultSet rs=ps.executeQuery();
		    return rs;
		}
		//������Щѧ����ʦ���Դ��
		public ResultSet returnstudentcanbenote2222222222222(int tttrslsid) throws SQLException
		{
			PreparedStatement ps=(PreparedStatement) conn.prepareStatement("select studentselect.courseid,studentid,studentgrade from studentselect where studentselect.courseid in(select teacherselect.courseid from teacherselect where teacherselect.teacherid=?)");
		    ps.setInt(1,tttrslsid);
		    ResultSet rs=ps.executeQuery();
		    return rs;
		}
		//��ʦ���ɼ�
		public boolean teachersetgrade(int stuid,String courna,int grade) throws SQLException
		{
			PreparedStatement ps=(PreparedStatement) conn.prepareStatement("update studentselect set studentgrade=? where studentid=? and courseid=?");
			ps.setInt(1, grade);
			ps.setInt(2, stuid);
			ps.setString(3, courna);
			int a=ps.executeUpdate();
			if(a==1)
			{
				return true;
			}
			return false;
		}
		//ѧ������
		public boolean xuehengpingjia(int stuids,String courname,String level,String remark) throws SQLException
		{
			PreparedStatement ps=(PreparedStatement) conn.prepareStatement("update studentselect set courselevel=?,coursesturemark=? where studentid=? and courseid=?");
			ps.setString(1, level);
			ps.setString(2, remark);
			ps.setInt(3, stuids);
			ps.setString(4, courname);
			int a=ps.executeUpdate();
			if(a==1)
			{
				return true;
			}
			return false;
		}
		//ѧ�����۱�
		public ResultSet returnstudentnote2222222222222232323232(int sssrslsid) throws SQLException
		{
			PreparedStatement ps=(PreparedStatement) conn.prepareStatement("select course.courseid,coursename,studentgrade,courselevel,coursesturemark from studentselect,course where course.courseid=studentselect.courseid and studentid=?");
		    ps.setInt(1, sssrslsid);
		    ResultSet rs=ps.executeQuery();
		    return rs;
		}
		//ADMIN�鿴 uoyou
		public ResultSet adminelect() throws SQLException
		{
			Statement ta=(Statement) conn.createStatement();
		    ResultSet rs=ta.executeQuery("select studentselect.courseid,coursename,teachername,studentselect.studentgrade,studentselect.coursesturemark,studentselect.courselevel from course,studentselect,teacher,teacherselect where course.courseid=studentselect.courseid and teacher.teacherid=teacherselect.teacherid and teacherselect.courseid=studentselect.courseid");
		    return rs;
		}

}

