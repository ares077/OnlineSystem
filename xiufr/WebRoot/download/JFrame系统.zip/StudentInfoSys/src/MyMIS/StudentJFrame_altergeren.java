package MyMIS;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class StudentJFrame_altergeren {
	private JLabel lb1,lb2,lb3,lb4,lb5,lb6,lb7,lb8,lb9;
	private JPasswordField pf1,pf2;
	private JTextField tf1,tf2,tf3;
	private JButton bt1;
	public int id;
	DataBaseIO dbi;
	private JPanel jp[];
	Regex rg;
	public StudentJFrame_altergeren(JPanel myPanel,DataBaseIO dbicanshu,int idcs) throws SQLException
	{
		rg=new Regex();
		for(int i=0;i<15;i++)
		{
			if(i==0)
			{
				jp=new JPanel[15];
			}
			jp[i]=new JPanel();
		}
		id=idcs;
		dbi=dbicanshu;
		pf1=new JPasswordField(20);
		pf2=new JPasswordField(20);
		tf1=new JTextField(20);
		tf2=new JTextField(20);
		tf3=new JTextField(20);
		lb1=new JLabel("����:",JLabel.CENTER);
		lb2=new JLabel("ȷ������:",JLabel.CENTER);
		lb3=new JLabel("����:",JLabel.CENTER);
		lb4=new JLabel("���䣺",JLabel.CENTER);
		lb5=new JLabel("�ֻ���",JLabel.CENTER);
		lb6=new JLabel("��",JLabel.CENTER);
		lb7=new JLabel("��",JLabel.CENTER);
		lb8=new JLabel("��",JLabel.CENTER);
		lb9=new JLabel("��",JLabel.CENTER);
		bt1=new JButton("ȷ���޸�");
		//bt1.setPreferredSize(new Dimension(20,20));
		myEvent();
		//д���ʼ����
		String str="student";
		ResultSet rs=dbi.selectone(str, id);
		rs.next();
		pf1.setText(rs.getNString("studentpw"));
		pf2.setText(rs.getNString("studentpw"));
		tf1.setText(rs.getNString("studentname"));
		tf2.setText(rs.getNString("studentmail"));
		tf3.setText(rs.getNString("studentphonum"));
		jp[1].add(lb1);
		jp[2].add(lb2);
		jp[3].add(lb3);
		jp[4].add(lb4);
		jp[5].add(lb5);
		jp[1].add(pf1);
		jp[2].add(pf2);
		jp[3].add(tf1);
		jp[4].add(tf2);
		jp[5].add(tf3);
		jp[0].setLayout(new GridLayout(6,2));
		jp[0].add(jp[1]);
		jp[0].add(lb6);
		jp[0].add(jp[2]);
		jp[0].add(lb7);
		jp[0].add(jp[3]);
		jp[0].add(jp[6]);
		jp[0].add(jp[4]);
		jp[0].add(lb8);
		jp[0].add(jp[5]);
		jp[0].add(lb9);
		jp[0].add(bt1);
		jp[0].add(jp[10]);
		jp[7].setLayout(new GridLayout(3,1));
		jp[7].add(jp[8]);
		jp[7].add(jp[0]);
		jp[7].add(jp[9]);
		myPanel.setLayout(new BorderLayout());
		myPanel.add(jp[7],BorderLayout.WEST);
		
	}
	private void myEvent()
	{
		
		//��������Ƿ�Ϸ�
		pf1.addMouseListener(new MouseAdapter(){
			
			public void mouseExited(MouseEvent e)
			{
				if(rg.pwisvalid(pf1.getText()))
				{
					lb6.setText("��");
				}else
				{
					lb6.setText("�������6-20λ");
				}
			}
		});
		pf2.addMouseListener(new MouseAdapter(){
			
			public void mouseEntered(MouseEvent e)
			{
				if(rg.pwisvalid(pf1.getText()))
				{
					lb6.setText("��");
				}else
				{
					lb6.setText("�������6-20λ");
				}
			}
		});
		//������������Ƿ���ͬ
		pf2.addMouseListener(new MouseAdapter(){
			public void mouseExited(MouseEvent e)
			{
				if(pf1.getText().equals(pf2.getText()))
				{
					lb7.setText("��");
				}else
				{
					lb7.setText("�������벻һ��");
				}
			}
		});
		tf1.addMouseListener(new MouseAdapter(){
			public void mouseEntered(MouseEvent e)
			{

				if(pf1.getText().equals(pf2.getText()))
				{
					lb7.setText("��");
				}else
				{
					lb7.setText("�������벻һ��");
				}
			}
		});
		//���������Ϸ�
		tf2.addMouseListener(new MouseAdapter(){
			public void mouseExited(MouseEvent e)
			{
				if(rg.mailisvalid(tf2.getText()))
				{
					lb8.setText("��");
				}else
				{
					lb8.setText("���䲻�Ϸ�");
				}
			}
		});
		tf3.addMouseListener(new MouseAdapter(){
			public void mouseEntered(MouseEvent e)
			{
				if(rg.mailisvalid(tf2.getText()))
				{
					lb8.setText("��");
				}else
				{
					lb8.setText("���䲻�Ϸ�");
				}
			}
		});
		//����ֻ��Ż��Ϸ�
		tf3.addMouseListener(new MouseAdapter(){
			public void mouseExited(MouseEvent e)
			{
				if(rg.phonumisvalid(tf3.getText()))
				{
					lb9.setText("��");
				}else
				{
					lb9.setText("�ֻ��Ų��Ϸ�");
				}
			}
		});
		bt1.addMouseListener(new MouseAdapter(){
			public void mouseEntered(MouseEvent e)
			{

				if(rg.phonumisvalid(tf3.getText()))
				{
					lb9.setText("��");
				}else
				{
					lb9.setText("�ֻ��Ų��Ϸ�");
					tf3.setText("");
				}
				if(!rg.mailisvalid(tf2.getText()))
				{
					tf2.setText("");
				}
				if(!rg.pwisvalid(pf1.getText()))
				{
					pf1.setText("");
				}
				if(!pf1.getText().equals(pf2.getText()))
				{
					pf1.setText("");
					pf2.setText("");
				}
			
			}
		});
		//д���޸�����
		bt1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				if(pf1.getText().isEmpty()||pf2.getText().isEmpty()||tf1.getText().isEmpty()||tf2.getText().isEmpty()||tf3.getText().isEmpty())
				{
					JOptionPane.showMessageDialog(null, "�п���");
				}else
				{
					try {
						if(dbi.isalterstudentinfo(id, pf2.getText(), tf1.getText(), tf2.getText(), tf3.getText()))
						{
							JOptionPane.showMessageDialog(null, "�޸ĳɹ�");
							pf1.setText("");
							pf2.setText("");
							tf1.setText("");
							tf2.setText("");
							tf3.setText("");
							lb6.setText("");
							lb7.setText("");
							lb8.setText("");
							lb9.setText("");
						}else
						{
							JOptionPane.showMessageDialog(null, "Error,199");
						}
					} catch (HeadlessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
	}


}
