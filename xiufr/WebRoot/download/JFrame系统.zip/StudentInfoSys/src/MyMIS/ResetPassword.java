package MyMIS;


import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.Serializable;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class ResetPassword implements Serializable{
	private static final long serialVersionUID=1L;
	private JFrame jm;
	private JLabel lb1,lb2,lb3,lb4,lb5,lb6;
	private JButton bt1,bt2;
	private JTextField tf;
	private JPasswordField pf1,pf2,pf3;
	private JPanel jp1,jp2,jp3,jp4,jp5,jp10;
	private String str1;
	DataBaseIO dbi;
	public ResetPassword(String str)
	{
		dbi=new DataBaseIO();
		jm=new JFrame("�޸�����");
		tf=new JTextField(20);
        lb1=new JLabel("����ѧ��:",JLabel.CENTER);
        lb2=new JLabel("ԭ����:",JLabel.CENTER);
        lb3=new JLabel("������:",JLabel.CENTER);
        lb4=new JLabel("�ٴ�����:",JLabel.CENTER);
        lb5=new JLabel("  ",JLabel.CENTER);
        lb6=new JLabel("  ",JLabel.CENTER);
        bt1=new JButton("ȷ���޸�");
        bt2=new JButton("��������");
        pf1=new JPasswordField(20);
        pf2=new JPasswordField(20);
        pf3=new JPasswordField(20);
        jp1=new JPanel();
        jp2=new JPanel();
        jp3=new JPanel();
        jp4=new JPanel();
        jp5=new JPanel();
        jp10=new JPanel();
		jm.setBounds(900, 300, 300, 300);
		jm.setIconImage(new ImageIcon("images/biaotitupian.png").getImage());
		jp10.setLayout(new GridLayout(5,1));
		jp1.add(lb1);
		jp1.add(tf);
		jp2.add(lb2);
		jp2.add(lb5);
		jp2.add(pf1);
		jp3.add(lb3);
		jp3.add(lb6);
		jp3.add(pf2);
		jp4.add(lb4);
		jp4.add(pf3);
		jp5.add(bt1);
		jp5.add(bt2);
		jp10.add(jp1);
		jp10.add(jp2);
		jp10.add(jp3);
		jp10.add(jp4);
		jp10.add(jp5);
		jm.add(jp10);
		MyEvent();
		jm.setResizable(false);
		jm.setVisible(true);
		str1=str;
		if(str=="teacher")
		{
			lb1.setText("��ʦ��:    ");
		}
	    //jm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void MyEvent()
	{
		//���ڹر�ʱ���˳�����ֻ�رյ�ǰ��JFrame
		jm.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e)
			{
				try {
					dbi.connClose();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				jm.dispose();
   		    }
		});
		//�������밴ť���¼�����
		bt2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				JOptionPane.showMessageDialog(jm, "����ϵ����Ա");
			}
		});
		//д�����ݿ�
		bt1.addActionListener(new ActionListener(){
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e)
			{
				if(pf2.getText().equals(pf3.getText()))
				{	
					if(new Regex().pwisvalid(pf2.getText().toString()))
					{					
						try{					
							if(str1=="teacher")
							{
								if(dbi.isalterpassword(str1,tf.getText().toString(),pf1.getText().toString(),pf2.getText().toString()))
								{
									JOptionPane.showMessageDialog(jm, "�޸ĳɹ�");
									clearall(0123);
								}
								else
								{
									JOptionPane.showMessageDialog(jm, "Error,�˺Ż��������");
									clearall(123);
								}
							}
							else
							{
								String str2="student";
								if(dbi.isalterpassword(str2,tf.getText().toString(),pf1.getText().toString(),pf2.getText().toString()))
								{
									JOptionPane.showMessageDialog(jm, "�޸ĳɹ�");
									clearall(0123);
								}
								else
								{
									JOptionPane.showMessageDialog(jm, "Error,�˺Ż��������");
									clearall(123);
								}
							}
						}catch(SQLException ee)
						{
							
						}
					}
					else
					{
						JOptionPane.showMessageDialog(jm, "�����벻��Ϊ��");
					}
				}
				else
				{
					JOptionPane.showMessageDialog(jm, "�����������벻һ��");
					clearall(23);
				}
			}
		});
		//����뿪ԭ�������ѧ���Ƿ�Ϸ�
		pf1.addFocusListener(new FocusListener(){
			public void focusGained(FocusEvent e) {		
			}
			public void focusLost(FocusEvent e) {
				if(new Regex().idisvalid(tf.getText().toString()))
				{
					
				}
				else
				{
					if(str1=="teacher")
					{
						JOptionPane.showMessageDialog(jm, "��ʦ�źŲ��Ϸ�������11λ");
						clearall(0);
					}else
					{						
						JOptionPane.showMessageDialog(jm, "ѧ�Ų��Ϸ�������11λ");
						clearall(0);
					}
				}
			}
		});
		//����뿪�������1ʱ��������Ƿ�Ϸ�
		pf2.addFocusListener(new FocusListener() 
		{
			@SuppressWarnings("deprecation")
			public void focusLost(FocusEvent e)
			{
				if(new Regex().pwisvalid(pf2.getText().toString()))
				{
					
				}
				else
				{
					JOptionPane.showMessageDialog(jm, "���벻�Ϸ�������6-20λ");
					clearall(2);
				}
			}
			public void focusGained(FocusEvent e)
			{
				
			}
		});
	}
	public  void clearall(int i)
	{
		if(i==123)
		{
			pf1.setText("");
			pf2.setText("");
			pf3.setText("");
		}
		else if(i==0123)
		{
			tf.setText("");
			pf1.setText("");
			pf2.setText("");
			pf3.setText("");			
		}
		else if(i==23)
		{
			pf2.setText("");
			pf3.setText("");	
		}
		else if(i==0)
		{
			tf.setText("");
		}
		else if(i==1)
		{
			pf1.setText("");
		}
		else if(i==2)
		{
			pf2.setText("");
		}
	}
}