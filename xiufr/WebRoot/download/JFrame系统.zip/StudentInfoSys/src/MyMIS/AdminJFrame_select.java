package MyMIS;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import com.mysql.jdbc.ResultSetMetaData;

public class AdminJFrame_select {
	private JLabel lb1;
	private JButton bt1,bt2;
	private JTextField tf1;
	private JPanel jp1,jp2;
	private JScrollPane scrollpane;
	DataBaseIO dbi;
	private String str;
	private String id;
	public AdminJFrame_select(String str1,JPanel myPanel,DataBaseIO dbicanshu,String idcs)
	{
		id=idcs;
		str=str1;
		dbi=dbicanshu;
		lb1=new JLabel("��������Ҫ��ѯ��ѧ��:",JLabel.CENTER);
		if(str=="teacher")
		{
			lb1.setText("��������Ҫ��ѯ�Ľ�ʦ��:");
		}
		if(str=="course")
		{
			lb1.setText("��������Ҫ��ѯ�Ŀγ̺�:");
		}
		bt1=new JButton("ȷ��");
		bt2=new JButton("��ѯ����");
		tf1=new JTextField(20);
		jp1=new JPanel();
		jp2=new JPanel();
		jp1.add(lb1);
		jp1.add(tf1);
		jp1.add(bt1);
		jp1.add(bt2);
		MyEvent();
		myPanel.setLayout(new BorderLayout());
		myPanel.add(jp1,BorderLayout.NORTH);
		myPanel.add(jp2,BorderLayout.CENTER);
		
	}
	public void MyEvent()
	{
		//�ж�ѧ���š���ʦ�š��γ̺��Ƿ�Ϸ�
		bt1.addMouseListener(new MouseAdapter()
		{
			public void mouseEntered(MouseEvent e)
			{
				if(str=="course")
				{
					if(new Regex().courseidisvalis(tf1.getText()))
					{
						
					}
					else
					{
						JOptionPane.showMessageDialog(null, "�γ̺Ų��Ϸ�");
					}
				}
				else
				{		
					if(new Regex().idisvalid(tf1.getText()))
					{
						
					}
					else
					{
						if(str=="teacher")
						{
							JOptionPane.showMessageDialog(null, "��ʦ�Ų��Ϸ�");
						}
						else
						{					
							JOptionPane.showMessageDialog(null, "ѧ�Ų��Ϸ�");
						}
					}
				}
			}
		});
		//��ѯ����
		bt1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(scrollpane!=null)
				{
					jp2.remove(scrollpane);
				}
				try{
					ResultSet rs=dbi.selectone(str, tf1.getText());
					if(rs.next())
					{
						rs.previous();
						ResultSetMetaData rsmd=(ResultSetMetaData) rs.getMetaData();
						Vector<String> columnames= new Vector<String>();
						Vector<Vector<String>> data=new Vector<Vector<String>>();
						/*
					for(int i=0;i<rsmd.getColumnCount();i++)
					{
						columnames.add(rsmd.getColumnName(i+1));
					}*/
						if(str=="student")
						{
							columnames.add("ѧ�����");
							columnames.add("ѧ������");
							columnames.add("ѧ������");
							columnames.add("�����ַ");
							columnames.add("�ֻ���");
						}else if(str=="course")
						{
							columnames.add("�γ̱��");
							columnames.add("�γ�����");
							columnames.add("�γ̵ص�");
							columnames.add("�γ�ʱ��");
							columnames.add("�γ̽���");							
						}else
						{
							columnames.add("��ʦ���");
							columnames.add("��ʦ����");
							columnames.add("��ʦ����");
							columnames.add("�����ַ");
							columnames.add("�ֻ���");	
						}
						while(rs.next())
						{
							Vector<String> v=new Vector<String>();
							for(int i=0;i<rsmd.getColumnCount();i++)
							{
								v.add(rs.getString(i+1));
							}
							data.add(v);
						}
						JTable table=new JTable(data,columnames);
						scrollpane=new JScrollPane(table);
						jp2.add(scrollpane);
						jp2.validate();		
					}
					else
					{
						JOptionPane.showMessageDialog(null, "������");
						if(scrollpane!=null)
						{
							jp2.remove(scrollpane);
							jp2.repaint();
						}
					}}
					catch(SQLException ee)
					{
						JOptionPane.showMessageDialog(null, ee);
						System.out.print(ee);
					}catch(Exception ee2)
					{
						JOptionPane.showMessageDialog(null, ee2);
						System.out.print(ee2);
					}
			}
		});
		//��ѯ����
		bt2.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(scrollpane!=null)
				{
					jp2.remove(scrollpane);
				}
				try{
					ResultSet rs=dbi.selectall(str);
					ResultSetMetaData rsmd=(ResultSetMetaData) rs.getMetaData();
					Vector<String> columnames= new Vector<String>();
					Vector<Vector<String>> data=new Vector<Vector<String>>();
					/*for(int i=0;i<rsmd.getColumnCount();i++)
					{
						columnames.add(rsmd.getColumnName(i+1));
					}*/
					if(str=="student")
					{
						columnames.add("ѧ�����");
						columnames.add("ѧ������");
						columnames.add("ѧ������");
						columnames.add("�����ַ");
						columnames.add("�ֻ���");
					}else if(str=="course")
					{
						columnames.add("�γ̱��");
						columnames.add("�γ�����");
						columnames.add("�γ̵ص�");
						columnames.add("�γ�ʱ��");
						columnames.add("�γ̽���");							
					}else
					{
						columnames.add("��ʦ���");
						columnames.add("��ʦ����");
						columnames.add("��ʦ����");
						columnames.add("�����ַ");
						columnames.add("�ֻ���");	
					}
					while(rs.next())
					{
						Vector<String> v=new Vector<String>();
						for(int i=0;i<rsmd.getColumnCount();i++)
						{
							v.add(rs.getString(i+1));
						}
						data.add(v);
					}
					JTable table=new JTable(data,columnames);
					scrollpane=new JScrollPane(table);
					jp2.add(scrollpane);
					jp2.validate();		
			}catch(SQLException ee)
				{
					JOptionPane.showMessageDialog(null, ee);
					System.out.print(ee);
				}catch(Exception ee2)
				{
					JOptionPane.showMessageDialog(null, ee2);
					System.out.print(ee2);
				}
			}
		});
		
	}

}
