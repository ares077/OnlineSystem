package MyMIS;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class AdminJFrame_addnew {
	private JPanel jp[];
	private JTextField tf1,tf2,tf3,tf4;
	private JPasswordField pf1,pf2;
	private JButton bt1,bt2;
	private JLabel lb1,lb2,lb3,lb4,lb5,lb6,lb7,lb8,lb9,lb10,lb11,lb12,lb13,lb14,lb15,lb16,lb17,lb18,lb19,lb20;
	private String str1;
	Regex rg;
	DataBaseIO dbi;
	private String id;
	public AdminJFrame_addnew(JPanel myPanel,String str,DataBaseIO dbicanshu,String idcanshu)
	{
		id=idcanshu;
	    dbi=dbicanshu;
		rg=new Regex();
		str1=str;
		for(int i=0;i<13;i++)
		{
			if(i==0)
			{
				 jp=new JPanel[13];		
			}
			jp[i]=new JPanel();
		}
		tf1=new JTextField(20);
		tf2=new JTextField(20);
		tf3=new JTextField(20);
		tf4=new JTextField(20);
		pf1=new JPasswordField(20);
		pf2=new JPasswordField(20);
		bt1=new JButton("ȷ������");
		bt2=new JButton("��������");
		lb1=new JLabel("ѧ��ѧ��:",JLabel.CENTER);
		lb2=new JLabel("ѧ������:",JLabel.CENTER);
		lb3=new JLabel("����:          ",JLabel.CENTER);
		lb4=new JLabel("�ٴ�ȷ��:",JLabel.CENTER);
		lb5=new JLabel("����:          ",JLabel.CENTER);
		lb6=new JLabel("�ֻ���:      ",JLabel.CENTER);
		lb7=new JLabel(" ");
		lb8=new JLabel("             ",JLabel.CENTER);
		lb9=new JLabel("             ",JLabel.CENTER);
		lb10=new JLabel(" ");	
		lb11=new JLabel(" ");	
		lb12=new JLabel(" ");
		lb13=new JLabel("     ",JLabel.CENTER);
		lb14=new JLabel("                     ",JLabel.CENTER);
		lb15=new JLabel("                    ",JLabel.CENTER);
		lb16=new JLabel("     ",JLabel.CENTER);
		lb17=new JLabel("     ",JLabel.CENTER);
		lb18=new JLabel("     ",JLabel.CENTER);
		lb19=new JLabel(" ");
		lb20=new JLabel("");
		if(str1=="teacher")
		{
			lb1.setText("��ʦ��:     ");
			lb2.setText("��ʦ����:");
		}
		if(str1=="student")
		{
			lb1.setText("ѧ��ѧ��:");
			lb2.setText("ѧ������:");
		}
		jp[0].setLayout(new GridLayout(8,2));
		jp[1].add(lb13);
		jp[2].add(lb14);
		jp[3].add(lb15);
		jp[4].add(lb16);
		jp[5].add(lb17);
		jp[6].add(lb18);
		jp[1].add(lb1);
		jp[2].add(lb2);
		jp[3].add(lb3);
		jp[4].add(lb4);
		jp[5].add(lb5);
		jp[6].add(lb6);	
		jp[1].add(tf1);
		jp[2].add(tf2);
		jp[2].add(lb8);
		jp[3].add(pf1);
		jp[3].add(lb9);
		jp[4].add(pf2);
		jp[5].add(tf3);
		jp[6].add(tf4);
		jp[8].add(bt1);
		jp[8].add(bt2);
		jp[0].add(jp[10]);
		jp[0].add(jp[11]);
		jp[0].add(jp[1]);
		jp[0].add(lb7);
		jp[0].add(jp[2]);
		jp[0].add(jp[12]);
		jp[0].add(jp[3]);
		jp[0].add(lb19);
		jp[0].add(jp[4]);
		jp[0].add(lb10);
		jp[0].add(jp[5]);
		jp[0].add(lb11);
		jp[0].add(jp[6]);
		jp[0].add(lb12);
		jp[0].add(jp[8]);
		jp[0].add(lb20);		
		MyEvent();
		myPanel.setLayout(new BorderLayout());
		myPanel.add(jp[0],BorderLayout.WEST);
	}
	private void MyEvent()
	{
		//�ж�ѧ�������Ƿ���ȷ
		tf1.addFocusListener(new FocusAdapter()
		{
			public void focusLost(FocusEvent e)
			{	
				if(rg.idisvalid(tf1.getText()))
				{
			         lb7.setText("��");
				}
				else if(str1=="teacher")
				{
					lb7.setText("��ʦ�źű���11λ����");
				}
				else
				{
					lb7.setText("ѧ�ű���11λ����");
				}

			}
		});
		tf2.addMouseListener(new MouseAdapter()
		{
			public void mouseEntered(MouseEvent e)
			{
				if(rg.idisvalid(tf1.getText()))
				{
			         lb7.setText("��");
				}
				else if(str1=="teacher")
				{
					lb7.setText("��ʦ�źű���11λ����");
				}
				else
				{
					lb7.setText("ѧ�ű���11λ����");
				}
			}
		});
		
		//�ж������Ƿ�6-20λ
		pf1.addFocusListener(new FocusAdapter()
		{
			@SuppressWarnings("deprecation")
			public void focusLost(FocusEvent e)
			{	
				if(rg.pwisvalid(pf1.getText().toString()))
				{
			         lb19.setText("��");
				}
				else
				{
					lb19.setText("�������6-20λ");
				}
			}
		});
		pf2.addMouseListener(new MouseAdapter()
		{
			@SuppressWarnings("deprecation")
			public void mouseEntered(MouseEvent e)
			{

				if(rg.pwisvalid(pf1.getText().toString()))
				{
			         lb19.setText("��");
				}
				else
				{
					lb19.setText("�������6-20λ");
				}
			}
		});
		//�ж����������Ƿ�һ��
		pf2.addFocusListener(new FocusAdapter()
		{
			@SuppressWarnings("deprecation")
			public void focusLost(FocusEvent e)
			{	
				if(pf1.getText().equals(pf2.getText()))
				{
			         lb10.setText("��");
				}
				else
				{
					lb10.setText("�������벻һ��");
					pf2.setText("");
				}
			}
		});
		tf3.addMouseListener(new MouseAdapter()
		{
			@SuppressWarnings("deprecation")
			public void mouseEntered(MouseEvent e)
			{

				if(pf1.getText().equals(pf2.getText()))
				{
			         lb10.setText("��");
				}
				else
				{
					lb10.setText("�������벻һ��");
					pf2.setText("");
				}
			}
		});
		//�ж������Ƿ�Ϸ�
		tf3.addFocusListener(new FocusAdapter()
		{
			public void focusLost(FocusEvent e)
			{	
				if(rg.mailisvalid(tf3.getText()))
				{
			         lb11.setText("��");
				}
				else
				{
					lb11.setText("��Ч����");
					tf3.setText("");
				}

			}
		});
		tf4.addMouseListener(new MouseAdapter()
		{
			public void mouseEntered(MouseEvent e)
			{

				if(rg.mailisvalid(tf3.getText()))
				{
			         lb11.setText("��");
				}
				else
				{
					lb11.setText("��Ч����");
					tf3.setText("");
				}
			}
		});
		//�������ȷ����ťʱ����ֻ������Ƿ���ȷ
		bt1.addMouseListener(new MouseAdapter()
		{
			public void mouseEntered(MouseEvent e)
			{
				if(rg.phonumisvalid(tf4.getText()))
				{
			         lb12.setText("��");
				}
				else
				{
					lb12.setText("��Ч����");
					tf4.setText("");
				}
			}
		});
		//��������
		bt2.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				tf1.setText("");
				tf2.setText("");
				tf3.setText("");
				tf4.setText("");
				pf1.setText("");
				pf2.setText("");
				lb7.setText("");
				lb10.setText("");
				lb11.setText("");
				lb12.setText("");
				lb19.setText("");
			}
		});
		//ȷ��д�����ݿ�
		bt1.addActionListener(new ActionListener()
		{
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e)
			{
				if(rg.idisvalid(tf1.getText())&&rg.pwisvalid(pf1.getText().toString())&&rg.mailisvalid(tf3.getText())&&rg.phonumisvalid(tf4.getText()))
				{
					if(str1=="teacher")
					{
						try {
							if(dbi.isexitteacoursestu(str1, tf1.getText()))
							{
								JOptionPane.showMessageDialog(null, "�Ѿ�����");
							}else
							{
								
								if(dbi.isaddnewcustom(str1, tf1.getText(), pf1.getText(), tf2.getText(), tf3.getText(),tf4.getText()))
								{
									JOptionPane.showMessageDialog(null, "���ӳɹ�");
									tf1.setText("");
									tf2.setText("");
									tf3.setText("");
									tf4.setText("");
									pf1.setText("");
									pf2.setText("");
									lb7.setText("");
									lb10.setText("");
									lb11.setText("");
									lb12.setText("");
									lb19.setText("");
								}
								else
								{
									JOptionPane.showMessageDialog(null, "Error�����ڴ���");
								}
							}
						} catch (HeadlessException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
					else
					{
						String str2="student";
						try {
							if(dbi.isexitteacoursestu(str2, tf1.getText()))
							{
								JOptionPane.showMessageDialog(null, "�Ѿ�����");
							}else
							{
							
								if(dbi.isaddnewcustom(str2, tf1.getText(), pf1.getText(), tf2.getText(), tf3.getText(),tf4.getText()))
								{
									JOptionPane.showMessageDialog(null, "���ӳɹ�");
									tf1.setText("");
									tf2.setText("");
									tf3.setText("");
									tf4.setText("");
									pf1.setText("");
									pf2.setText("");
									lb7.setText("");
									lb10.setText("");
									lb11.setText("");
									lb12.setText("");
									lb19.setText("");
								}
								else
								{
									JOptionPane.showMessageDialog(null, "Error�����ڴ���");
								}
							}
						} catch (HeadlessException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
				else
				{
					JOptionPane.showMessageDialog(null, "��д�д���");
				}
			}
		});
	}
}
