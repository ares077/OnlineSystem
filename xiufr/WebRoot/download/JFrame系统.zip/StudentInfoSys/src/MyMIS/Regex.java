package MyMIS;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Regex {
	Pattern p;
	public boolean courseidisvalis(String a)
	{
		p=Pattern.compile("\\D\\d\\d\\d\\d");
		Matcher m=p.matcher(a);
		boolean b=m.matches();
		return b;
	}
	public boolean gradeisvaled(String a)
	{
		p=Pattern.compile("\\d\\d");
		Pattern p2=Pattern.compile("\\d");
		Matcher m=p.matcher(a);
		Matcher m2=p2.matcher(a);
		boolean b=m.matches();
		boolean b2=m2.matches();
		boolean b3=b||b2;
		boolean abc;
		int grade=Integer.parseInt(a);
		if(grade>=0&&grade<=100)
		{
			abc=true;
		}else
		{
			abc=false;
		}
		return (b3&&abc);
		
	}
	public boolean pwisvalid(String a)
	{
		p=Pattern.compile(".{6,20}");
		Matcher m=p.matcher(a);
		boolean b=m.matches();
		return b;		
	}
	public boolean idisvalid(String a)
	{
		p=Pattern.compile("\\d{11}");
		Pattern p2=Pattern.compile("\\d{4}");
		Matcher m=p.matcher(a);
		Matcher m2=p2.matcher(a);
		boolean b=m.matches();
		boolean b2=m2.matches();
		return (b|b2);		
	}
	public boolean phonumisvalid(String a)
	{
		p=Pattern.compile("^[1][3,4,5,8][0-9]{9}$");
		Matcher m=p.matcher(a);
		boolean b=m.matches();
		return b;		
	}
	public boolean mailisvalid(String a)
	{
		p=Pattern.compile("\\w{3,20}@(qq|hotmail|sina|yahoo|126|163|gmail|sohu|sogou)+\\.(com|org|cn|net|gov)");
		Matcher m=p.matcher(a);
		boolean b=m.matches();
		return b;		
	}
	
	

}
