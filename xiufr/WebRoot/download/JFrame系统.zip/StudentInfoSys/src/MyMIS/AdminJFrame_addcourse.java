package MyMIS;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class AdminJFrame_addcourse {
	private JPanel jp[];
	private JLabel lb1,lb2,lb3,lb4,lb5;
	private JTextField tf1,tf2,tf3,tf4;
	private JTextArea ta1,ta2;
	private JButton bt1,bt2;
	private JScrollPane sp1,sp2;
	DataBaseIO dbi;
	private String id;
	public AdminJFrame_addcourse(JPanel myPanel,DataBaseIO dbicanshu,String idcanshu)
	{
		id=idcanshu;
		dbi=dbicanshu;
		for(int i=0;i<13;i++)
		{
			if(i==0)
			{
				 jp=new JPanel[13];		
			}
			jp[i]=new JPanel();
		}
		lb1=new JLabel("�γ̱��",JLabel.CENTER);
		lb2=new JLabel("�γ�����",JLabel.CENTER);
		lb3=new JLabel("�γ̵ص�",JLabel.CENTER);
		lb4=new JLabel("�γ�ʱ��",JLabel.CENTER);
		lb5=new JLabel("�γ̼��",JLabel.CENTER);
		tf1=new JTextField(20);
		tf2=new JTextField(20);
		tf3=new JTextField(20);
		tf4=new JTextField(20);
	    ta1=new JTextArea(5,15);
	    ta2=new JTextArea(5,15);
	    //ta1.setLineWrap(true);
	    ta2.setLineWrap(true);
	    bt1=new JButton("ȷ������");
	    bt2=new JButton("��������");
	    //sp1=new JScrollPane(ta1);
	    sp2=new JScrollPane(ta2);	    
	    //sp1.add(ta1);
	    //sp2.add(ta2);	    
	    //sp1.setAutoscrolls(true);
	    sp2.setAutoscrolls(true);   
	    jp[9].add(tf4);
	    jp[10].add(sp2);
		jp[1].add(lb1);
		jp[1].add(tf1);
		jp[2].add(lb2);
		jp[2].add(tf2);
		jp[3].add(lb3);
		jp[3].add(tf3);
		jp[4].add(lb4);
		jp[4].add(tf4);
		jp[5].add(lb5);
		jp[5].add(sp2);
		jp[6].add(bt1);
		jp[6].add(bt2);
		jp[0].setLayout(new GridLayout(8,1));
		jp[0].add(jp[7]);
		jp[0].add(jp[1]);
		jp[0].add(jp[2]);
		jp[0].add(jp[3]);
		jp[0].add(jp[4]);
		jp[0].add(jp[5]);
		jp[0].add(jp[6]);
		jp[0].add(jp[8]);
		MyEvent();
		myPanel.setLayout(new BorderLayout());
		myPanel.add(jp[0],BorderLayout.WEST);	
	}
	private void MyEvent()
	{
		//���γ̱���Ƿ�Ϸ�
		tf2.addMouseListener(new MouseAdapter()
		{
			public void mouseEntered(MouseEvent e)
			{
				if(new Regex().courseidisvalis(tf1.getText()))
				{
					
				}
				else
				{
					JOptionPane.showMessageDialog(null,"�γ̱�Ų��Ϸ�");
				}
			}
		});
		bt1.addMouseListener(new MouseAdapter()
		{
			public void mouseEntered(MouseEvent e)
			{
					if(new Regex().courseidisvalis(tf1.getText()))
					{
						
					}
					else
					{
						JOptionPane.showMessageDialog(null,"�γ̱�Ų��Ϸ�");
					}
			}
		});
		//��������
		bt2.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				tf1.setText("");
				tf2.setText("");
				tf3.setText("");
				ta1.setText("");
				ta2.setText("");		
			}
		});
		//ȷ������ д�����ݿ�
		bt1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(tf1.getText().isEmpty()||tf2.getText().isEmpty()||tf3.getText().isEmpty()||tf4.getText().isEmpty())
				{
					JOptionPane.showMessageDialog(null, "ǰ�������Ϊ��");					
				}
				else
				{
					try {
						String str1="course";
						if(dbi.isexitteacoursestu(str1, tf1.getText()))
						{
							JOptionPane.showMessageDialog(null, "�Ѿ�����");
						}else
						{
							
							if(dbi.isaddnewcourse(tf1.getText(), tf2.getText(), tf3.getText(),tf4.getText(),ta2.getText() ))
							{
								JOptionPane.showMessageDialog(null, "���ӳɹ�");
								tf1.setText("");
								tf2.setText("");
								tf3.setText("");
								tf4.setText("");
								ta2.setText("");	
							}
							else
							{
								JOptionPane.showMessageDialog(null, "���ڴ���");
							}
						}
					} catch (HeadlessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
	}

}
