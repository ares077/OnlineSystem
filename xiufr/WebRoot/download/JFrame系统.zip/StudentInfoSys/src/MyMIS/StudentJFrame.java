package MyMIS;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

public class StudentJFrame {
	public int id;
	private JFrame StudentJFrame1;
	private JMenuBar menu;
	private JMenu me1,me2,me3;
	private JMenuItem me11,me12,me13,me21,me22,me33;
	private JPanel myPanel;
	DataBaseIO dbi;
	public StudentJFrame(int idcs)
	{
		id=idcs;
		dbi=new DataBaseIO();
		StudentJFrame1=new JFrame("��ӭʹ����ү������ϵͳ");
		menu=new JMenuBar();
		me1=new JMenu("��ѯ��Ϣ");
		me11=new JMenuItem("��ѯ/�޸ĸ�����Ϣ");
		me12=new JMenuItem("��ѯ��ѡ�γ���Ϣ");
		me13=new JMenuItem("��ѯ���Ƴɼ�");
		me2=new JMenu("ѧҵ���");
		me21=new JMenuItem("ѡ��γ�");
		me22=new JMenuItem("���۽�ʦ");
		me33=new JMenuItem("������Ϣ");
		me3=new JMenu("������Ϣ");
		myPanel=new JPanel();
		StudentJFrame1.setBounds(200, 100, 1000, 600);
		StudentJFrame1.setIconImage(new ImageIcon(StudentJFrame.class.getResource("biaotitupian.png")).getImage());	
		menu.add(me1);
		menu.add(me2);
		menu.add(me3);
		me1.add(me11);
		me1.add(me12);
		me1.add(me13);
		me2.add(me21);
		me2.add(me22);
		me3.add(me33);
		StudentJFrame1.setJMenuBar(menu);
		StudentJFrame1.add(myPanel);
		StudentJFrame1.setResizable(false);
		StudentJFrame1.setResizable(false);
		StudentJFrame1.setVisible(true);	
		MyEvent();
		
	}
	private void MyEvent()
	{
		//���ڹر�
		StudentJFrame1.addWindowFocusListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				try {
					dbi.connClose();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		//��ѯ�޸ĸ�����Ϣ
		me11.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				myPanel.removeAll();
				try {
					new StudentJFrame_altergeren(myPanel,dbi,id);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				myPanel.repaint();
				myPanel.validate();
			}
		});
		//��ѯ��xuan ke����Ϣ
		me12.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				myPanel.removeAll();
				new StudentJFrame_chaxunselectcourse(myPanel,dbi,id);
				myPanel.repaint();
				myPanel.validate();
			}
		});
		//��ѯ�ɼ�
		me13.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				myPanel.removeAll();
				new StudentJFrame_chaxunnotes(myPanel,dbi,id);
				myPanel.repaint();
				myPanel.validate();
			}
		});
		//ѡ��γ�
		me21.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				myPanel.removeAll();
				new StudentJFrame_xuankeselectcourse(myPanel,dbi,id);
				myPanel.repaint();
				myPanel.validate();
			}
		});
		//���۽�ʦ
		me22.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				myPanel.removeAll();
				new StudentJFrame_jiaoxuepingjia(myPanel,dbi,id);
				myPanel.repaint();
				myPanel.validate();
			}
		});
		//������Ϣ
		me33.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				myPanel.removeAll();
				new StudentJFrame_fankuiinfo(myPanel,dbi,id);
				myPanel.repaint();
				myPanel.validate();
				
			}
		});
		
	}

}
