package MyMIS;



import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import MyFiveGame.FrameFiveGame;

public class AdminJFrame implements Serializable{
	private static final long serialVersionUID=1L;
	private String id;
	private JFrame AdminJFrame1;
	private JMenuBar menu;
	private JMenu me1,me2,me3,me4,me5;
	private JMenuItem me1it1,me1it2,me1it3,me2it1,me2it2,me2it3,me3it1,me3it2,me3it3,me3it4,me3it5,me3it6;
	private JMenuItem me411,me412,me51,me52;
	private JPanel myPanel;
	DataBaseIO dbi;
	public AdminJFrame(String idcanshu)
	{
		id=idcanshu;
		dbi=new DataBaseIO();
		AdminJFrame1=new JFrame("��ӭʹ����ү������ϵͳ");
		menu=new JMenuBar();
		me1=new JMenu("�������û�");
		me2=new JMenu("�޸������û�");
		me3=new JMenu("��ѯ�����û�");
		me4=new JMenu("С��Ϸ");
		me5=new JMenu("��үdeż��");
		me1it1=new JMenuItem("�����½�ʦ");
		me1it2=new JMenuItem("������ѧ��");
		me1it3=new JMenuItem("�����¿γ�");
		me2it1=new JMenuItem("�޸����н�ʦ����");
		me2it2=new JMenuItem("�޸�����ѧ������");
		me2it3=new JMenuItem("�޸����пγ���Ϣ");
		me3it1=new JMenuItem("�������н�ʦ��Ϣ");
		me3it2=new JMenuItem("��ѯ����ѧ����Ϣ");
		me3it3=new JMenuItem("��ѯ���пγ���Ϣ");
		me3it4=new JMenuItem("��ѯ��ʦ������Ϣ");
		me3it5=new JMenuItem("��ѯѧ��������Ϣ");
		me3it6=new JMenuItem("��ѯ��ѧЧ��");
		me411=new JMenuItem("������");
		me412=new JMenuItem("̹�˴�ս");
		me51=new JMenuItem("GEM������");
		me52=new JMenuItem("��ү");
		myPanel=new JPanel();
		AdminJFrame1.setBounds(200, 100, 1000, 600);
		AdminJFrame1.setIconImage(new ImageIcon(AdminJFrame.class.getResource("biaotitupian.png")).getImage());
		me1.add(me1it1);
		me1.add(me1it2);
		me1.add(me1it3);
		me2.add(me2it1);
		me2.add(me2it2);
		me2.add(me2it3);
		me3.add(me3it1);
		me3.add(me3it2);
		me3.add(me3it3);
		me3.add(me3it4);
		me3.add(me3it5);
		me3.add(me3it6);
		me4.add(me411);
		me4.add(me412);
		me5.add(me51);
		me5.add(me52);
		menu.add(me1);
		menu.add(me2);
		menu.add(me3);
		menu.add(me4);
		menu.add(me5);
		AdminJFrame1.setJMenuBar(menu);
		AdminJFrame1.add(myPanel);
		AdminJFrame1.setResizable(false);
		AdminJFrame1.setVisible(true);
		MyEvent();
	}
	private void MyEvent()
	{
		//���ڹر��¼�
		AdminJFrame1.addWindowFocusListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				try {
					dbi.connClose();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		//������ѧ��
		me1it2.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) {
				myPanel.removeAll();
				new AdminJFrame_addnew(myPanel,"student",dbi,id);
				myPanel.repaint();
				AdminJFrame1.setVisible(true);
			}			
		});
		//�����½�ʦ
		me1it1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e) {
				myPanel.removeAll();
				new AdminJFrame_addnew(myPanel,"teacher",dbi,id);
				myPanel.repaint();
				AdminJFrame1.setVisible(true);
			}			
		});
		me1it3.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				myPanel.removeAll();
				new AdminJFrame_addcourse(myPanel,dbi,id);
				myPanel.repaint();
				AdminJFrame1.setVisible(true);
			}
		});
		//��ѯ��ʦ
		me3it1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				myPanel.removeAll();
				String str1="teacher";
				new AdminJFrame_select(str1,myPanel,dbi,id);
				myPanel.repaint();
				AdminJFrame1.setVisible(true);
			}
		});
		//��ѯѧ��
		me3it2.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				myPanel.removeAll();
				String str1="student";
				new AdminJFrame_select(str1,myPanel,dbi,id);
				myPanel.repaint();
				AdminJFrame1.setVisible(true);
			}
		});
		//��ѯ�γ�
		me3it3.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				myPanel.removeAll();
				String str1="course";
				new AdminJFrame_select(str1,myPanel,dbi,id);
				myPanel.repaint();
				AdminJFrame1.setVisible(true);
			}
		});
		//�޸����н�ʦ��ѧ����Ϣ��
		me2it1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				myPanel.removeAll();
				String str1="teacher";
				new AdminJFrame_alterts(str1,myPanel,dbi,id);
				myPanel.repaint();
				myPanel.validate();
			}
		});
		me2it2.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				myPanel.removeAll();
				String str1="student";
				new AdminJFrame_alterts(str1,myPanel,dbi,id);
				myPanel.repaint();
				myPanel.validate();
			}
		});
		//��������Ϸ
		me411.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				new FrameFiveGame();
			}
		});
		//GEM������
		me51.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				myPanel.removeAll();
				try {
					new AdminJFrame_GEM(myPanel);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				myPanel.repaint();
				myPanel.validate();
			}
		});
		//�޸Ŀγ�
		me2it3.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				myPanel.removeAll();
				new AdminJFrame_altercourse(myPanel,dbi,id);
				myPanel.repaint();
				myPanel.validate();
			}
		});
		//��ѯ��ʦ������Ϣ
		me3it4.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						myPanel.removeAll();
						myPanel.repaint();
						myPanel.validate();
						File fi3=new File("teacherfankui.txt");
						if(fi3.exists())
						{
							String str1=fi3.getPath();
							String str2="cmd /c start "+str1;
						
							try {	
								Runtime.getRuntime().exec(str2);
								fi3=null;
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
						else
						{
							JOptionPane.showMessageDialog(null, "������");
						}
						
					}
				});
		//��ѯѧ��������Ϣ
				me3it5.addActionListener(new ActionListener()
						{
							public void actionPerformed(ActionEvent e)
							{
								myPanel.removeAll();
								myPanel.repaint();
								myPanel.validate();
								File fi2=new File("studentfankui.txt");
								if(fi2.exists())
								{
									String str1=fi2.getPath();
									String str2="cmd /c start "+str1;		
									try {
										Runtime.getRuntime().exec(str2);
										fi2=null;
									} catch (IOException e1) {
										// TODO Auto-generated catch block
										e1.printStackTrace();
									}
								}
								else
								{
									JOptionPane.showMessageDialog(null, "������");
								}
							}
						});
		//��ѯЧ��
				//�޸Ŀγ�
				me3it6.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						myPanel.removeAll();
						new AdminJFrame_chaxunxiaoguo(myPanel,dbi,id);
						myPanel.repaint();
						myPanel.validate();
					}
				});
		
	}
}
