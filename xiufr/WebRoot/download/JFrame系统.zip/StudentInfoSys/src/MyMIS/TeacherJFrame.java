package MyMIS;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

public class TeacherJFrame {
	public int id;
	private JFrame TeacherJFrame1;
	private JMenuBar menu;
	private JMenu me1,me2,me3;
	private JMenuItem me11,me12,me21,me22,me23,me33;
	private JPanel myPanel;
	DataBaseIO dbi;
	public TeacherJFrame(int idcs)
	{
		id=idcs;
		dbi=new DataBaseIO();
		TeacherJFrame1=new JFrame("��ӭʹ����ү������ϵͳ");
		menu=new JMenuBar();
		me1=new JMenu("��ѯ��Ϣ");
		me11=new JMenuItem("��ѯ/�޸ĸ�����Ϣ");
		me12=new JMenuItem("��ѯ���ڿγ���Ϣ");
		me2=new JMenu("��ѧ��Ϣ");
		me21=new JMenuItem("ѡ�����ڿγ�");
		me22=new JMenuItem("���Ŀγ�");	
		me23=new JMenuItem("¼��ɼ�");
		me33=new JMenuItem("������Ϣ");
		me3=new JMenu("������Ϣ");
		myPanel=new JPanel();
		TeacherJFrame1.setBounds(200, 100, 1000, 600);
		TeacherJFrame1.setIconImage(new ImageIcon(TeacherJFrame.class.getResource("biaotitupian.png")).getImage());	
		menu.add(me1);
		menu.add(me2);
		menu.add(me3);
		me1.add(me11);
		me1.add(me12);
		me2.add(me21);
		me2.add(me22);
		me2.add(me23);
		me3.add(me33);
		TeacherJFrame1.setJMenuBar(menu);
		TeacherJFrame1.add(myPanel);
		TeacherJFrame1.setResizable(false);
		TeacherJFrame1.setResizable(false);
		TeacherJFrame1.setVisible(true);	
		MyEvent();
		
	}
	private void MyEvent()
	{
		//���ڹر�
		TeacherJFrame1.addWindowFocusListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				try {
					dbi.connClose();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		//��ѯ�޸ĸ�����Ϣ
		me11.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				myPanel.removeAll();
				try {
					new TeacherJFrame_alterinfo(myPanel,dbi,id);
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				myPanel.repaint();
				myPanel.validate();
			}
		});
		//��ѯ���ڿγ���Ϣ
		me12.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				myPanel.removeAll();
				new TeacherJFrame_selectallinfo(myPanel,dbi,id);
				myPanel.repaint();
				myPanel.validate();
			}
		});
		//ѡ�����ڿγ�
		me21.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				myPanel.removeAll();
				new TercherJFrame_xuanke(myPanel,dbi,id);
				myPanel.repaint();
				myPanel.validate();
			}
		});
		//����ѡ��γ̵���Ϣ
		me22.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				myPanel.removeAll();
				new TercherJFrame_genggai(myPanel,dbi,id);
				myPanel.repaint();
				myPanel.validate();
			}
		});
		//¼��ɼ�
				me23.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent e)
					{
						myPanel.removeAll();
						new TercherJFrame_setgrade(myPanel,dbi,id);
						myPanel.repaint();
						myPanel.validate();
					}
				});
		//������Ϣ
		me33.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				myPanel.removeAll();
				new TercherJFrame_fankuixinxi(myPanel,dbi,id);
				myPanel.repaint();
				myPanel.validate();
				
			}
		});
		
	}

}
