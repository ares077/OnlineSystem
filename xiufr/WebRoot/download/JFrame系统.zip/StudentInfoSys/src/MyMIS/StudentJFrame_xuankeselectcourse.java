package MyMIS;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class StudentJFrame_xuankeselectcourse {
	private JLabel lb1,lb2,lb3;
	private JButton bt1,bt2;
	private JScrollPane scrollpane1;
	private JScrollPane scrollpane2;
	private JTextField tf1;
	private int id;
	DataBaseIO dbi;
	private JPanel jp[];
	public StudentJFrame_xuankeselectcourse(JPanel myPanel,DataBaseIO dbicanshu,int ids)
	{
		dbi=dbicanshu;
		id=ids;
		lb1=new JLabel("���пγ�                                         ",JLabel.CENTER);
		lb2=new JLabel("                    ���Ŀγ�",JLabel.CENTER);
		lb3=new JLabel("������γ̺�:",JLabel.CENTER);
		bt1=new JButton("ȷ��ѡ��");
		bt2=new JButton("ȷ����ѡ");
		tf1=new JTextField(20);
		for(int i=0;i<15;i++)
		{
			if(i==0)
			{
				jp=new JPanel[15];
			}
			jp[i]=new JPanel();
		}	
		jp[5].setLayout(new GridLayout(2,1));
		jp[6].add(lb3);
		jp[6].add(tf1);
		jp[7].add(bt1);
		jp[7].add(bt2);
		jp[5].add(jp[6]);
		jp[5].add(jp[7]);
		jp[3].setLayout(new FlowLayout());
		jp[3].add(lb1);
		jp[3].add(jp[5]);
		jp[3].add(lb2);
		SetData1();
		SetData2();
		myEvent();
		myPanel.setLayout(new BorderLayout());
		myPanel.add(jp[2],BorderLayout.CENTER);
		myPanel.add(jp[1],BorderLayout.EAST);
		myPanel.add(jp[3],BorderLayout.NORTH);	
	}
	//д���ʼ����
	private void SetData1()
	{
		if(scrollpane2!=null)
		{
			jp[2].remove(scrollpane2);
		}
		try{
			ResultSet rs=dbi.returencoursewithtacher();
			//ResultSetMetaData rsmd=(ResultSetMetaData) rs.getMetaData();
			Vector<String> columnames= new Vector<String>();
			Vector<Vector<String>> data=new Vector<Vector<String>>();
			columnames.add("�γ̱��");
			columnames.add("�γ�����");
			columnames.add("�γ̵ص�");
			columnames.add("�γ�ʱ��");
			columnames.add("��ʦ����");
			columnames.add("��������");
			columnames.add("�γ̼��");
			while(rs.next())
			{
				Vector<String> v=new Vector<String>();	
				v.add(rs.getString("courseid"));
				v.add(rs.getString("coursename"));
				v.add(rs.getString("courseadress"));
				v.add(rs.getString("courseintro"));
				v.add(rs.getString("teachername"));
				v.add(rs.getString("teacherlevel"));
				v.add(rs.getString("courseaview"));
				data.add(v);
			}
			JTable table=new JTable(data,columnames);
			scrollpane2=new JScrollPane(table);
			jp[2].add(scrollpane2);
			jp[2].validate();	
		}
			catch(SQLException ee)
			{
				JOptionPane.showMessageDialog(null, ee);
				System.out.print(ee);
			}catch(Exception ee2)
			{
				JOptionPane.showMessageDialog(null, ee2);
				System.out.print(ee2);
			}
	}
	private void SetData2()
	{
		if(scrollpane1!=null)
		{
			jp[1].remove(scrollpane1);
		}
		try{
			
			ResultSet rs=dbi.returnstudentalreadyselectcourse(id);
			rs.previous();
			Vector<String> columnames= new Vector<String>();
			Vector<Vector<String>> data=new Vector<Vector<String>>();
			columnames.add("�γ̱��");
			columnames.add("�γ�����");
			columnames.add("�γ̵ص�");
			columnames.add("�γ�ʱ��");
			columnames.add("��ʦ����");
			while(rs.next())
			{
				Vector<String> v=new Vector<String>();
				v.add(rs.getString("courseid"));
				v.add(rs.getString("coursename"));
				v.add(rs.getString("courseadress"));
				v.add(rs.getString("courseintro"));
				v.add(rs.getString("teachername"));
				data.add(v);
			}
			JTable table=new JTable(data,columnames);
			scrollpane1=new JScrollPane(table);
			jp[1].add(scrollpane1);
			jp[1].validate();	
		}
			catch(SQLException ee)
			{
				JOptionPane.showMessageDialog(null, ee);
				System.out.print(ee);
			}catch(Exception ee2)
			{
				JOptionPane.showMessageDialog(null, ee2);
				System.out.print(ee2);
			}
	}
	//д���¼�
	private void myEvent()
	{
		//���γ̺��Ƿ�Ϸ�
		bt1.addMouseListener(new MouseAdapter(){
			public void mouseEntered(MouseEvent e)
			{
				if(new Regex().courseidisvalis(tf1.getText()))
						{
					
						}else
						{
							JOptionPane.showMessageDialog(null, "��������ȷ�Ŀγ̺�");
						}
			}
		});
				bt2.addMouseListener(new MouseAdapter(){
					public void mouseEntered(MouseEvent e)
					{
						if(new Regex().courseidisvalis(tf1.getText()))
								{
							
								}else
								{
									JOptionPane.showMessageDialog(null, "��������ȷ�Ŀγ̺�");
									tf1.setText("");
								}
					}
				});
		//���ӿγ�
		bt1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				if(new Regex().courseidisvalis(tf1.getText()))
				{
					try {
						if(dbi.isexisturselectcourse(tf1.getText(),id))
						{
							JOptionPane.showMessageDialog(null, "���Ѿ�ѡ�����ſγ���");
						}else
						{
							
							if(dbi.isexitedteacherselectcoursecanbestuident(tf1.getText()))
							{
								if(dbi.isstuselectcourse(tf1.getText(), id))
								{
									JOptionPane.showMessageDialog(null, "���ӳɹ�");
									tf1.setText("");
									SetData2();
									
								}else
								{
									JOptionPane.showMessageDialog(null, "Error,152");
								}

							}else{
								JOptionPane.showMessageDialog(null, "���������ſΣ�����");	
								tf1.setText("");
							}
						}
					} catch (HeadlessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				else
				{
					JOptionPane.showMessageDialog(null, "��������ȷ�Ŀγ̺�");
					tf1.setText("");
				}
			}
		});
		//ɾ���γ�
		bt2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				if(new Regex().courseidisvalis(tf1.getText()))
				{
					try {
						if(dbi.isexisturselectcourse(tf1.getText(),id))
						{
							if(dbi.isdelectstuselectcourse(tf1.getText(), id))
							{
								JOptionPane.showMessageDialog(null, "ɾ���ɹ�");
								tf1.setText("");
								SetData2();
							}
							else
							{
								JOptionPane.showMessageDialog(null, "ERROR 190");
							}
						}else
						{
							JOptionPane.showMessageDialog(null, "��ûѡ���ſγ̣���ôɾ����");
							tf1.setText("");
						}
					} catch (HeadlessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				else
				{
					JOptionPane.showMessageDialog(null, "��������ȷ�Ŀγ̺�");
					tf1.setText("");
				}
			}
		});
	}
	

}
