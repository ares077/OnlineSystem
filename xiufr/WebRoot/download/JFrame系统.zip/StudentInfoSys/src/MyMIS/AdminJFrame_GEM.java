package MyMIS;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.imageio.stream.ImageInputStream;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

public class AdminJFrame_GEM {
	private JPanel jp1,jp2,jp3,jp4,jp5,jp6,jp7,jp8,jp9,jp10,jp0,jp11;
	private JButton bt1,bt2;
	private BufferedImage GEM1,GEM2,GEM3,GEM4,GEM5,GEM6,GEM7,GEM8,GEM9,GEM10;
	final CardLayout clo;
	@SuppressWarnings("serial")
	public  AdminJFrame_GEM(JPanel myPanel) throws IOException
	{
		clo=new CardLayout();
		GEM1=ImageIO.read((ImageInputStream) new ImageIcon(AdminJFrame_GEM.class.getResource("GEM1.JPG")));
		GEM2=ImageIO.read((ImageInputStream) new ImageIcon(AdminJFrame_GEM.class.getResource("GEM2.JPG")));
		GEM3=ImageIO.read((ImageInputStream) new ImageIcon(AdminJFrame_GEM.class.getResource("GEM3.JPG")));
		GEM4=ImageIO.read((ImageInputStream) new ImageIcon(AdminJFrame_GEM.class.getResource("GEM4.JPG")));
		GEM5=ImageIO.read((ImageInputStream) new ImageIcon(AdminJFrame_GEM.class.getResource("GEM5.JPG")));
		GEM6=ImageIO.read((ImageInputStream) new ImageIcon(AdminJFrame_GEM.class.getResource("GEM6.JPG")));
		GEM7=ImageIO.read((ImageInputStream) new ImageIcon(AdminJFrame_GEM.class.getResource("GEM7.JPG")));
		GEM8=ImageIO.read((ImageInputStream) new ImageIcon(AdminJFrame_GEM.class.getResource("GEM8.JPG")));
		GEM9=ImageIO.read((ImageInputStream) new ImageIcon(AdminJFrame_GEM.class.getResource("GEM9.JPG")));
		GEM10=ImageIO.read((ImageInputStream) new ImageIcon(AdminJFrame_GEM.class.getResource("GEM10.JPG")));
		bt1=new JButton("��һ��");
		bt2=new JButton("��һ��");
		jp1=new JPanel(){
			public void paintComponent(Graphics g)
			{
				g.drawImage(GEM1, 0, 0, 500, 700, jp1);
			}
		};
		jp2=new JPanel(){
			public void paintComponent(Graphics g)
			{
				g.drawImage(GEM2, 0, 0, 500, 700, jp2);
			}
		};
		jp3=new JPanel(){
			public void paintComponent(Graphics g)
			{
				g.drawImage(GEM3, 0, 0, 500, 700, jp3);
			}
		};
		jp4=new JPanel(){
			public void paintComponent(Graphics g)
			{
				g.drawImage(GEM4, 0, 0, 500, 700, jp4);
			}
		};
		jp5=new JPanel(){
			public void paintComponent(Graphics g)
			{
				g.drawImage(GEM5, 0, 0, 500, 700, jp5);
			}
		};
		jp6=new JPanel(){
			public void paintComponent(Graphics g)
			{
				g.drawImage(GEM6, 0, 0, 500, 520, jp6);
			}
		};
		jp7=new JPanel(){
			public void paintComponent(Graphics g)
			{
				g.drawImage(GEM7, 0, 0, 500, 700, jp7);
			}
		};
		jp8=new JPanel(){
			public void paintComponent(Graphics g)
			{
				g.drawImage(GEM8, 0, 0, 500, 700, jp8);
			}
		};
		jp9=new JPanel(){
			public void paintComponent(Graphics g)
			{
				g.drawImage(GEM9, 0, 0, 500, 520, jp9);
			}
		};
		jp10=new JPanel(){
			public void paintComponent(Graphics g)
			{
				g.drawImage(GEM10, 0, 0, 500, 700, jp10);
			}
		};
		jp0=new JPanel();
		jp11=new JPanel();
		jp0.setLayout(clo);
		jp0.add(jp1,"1");
		jp0.add(jp2,"2");
		jp0.add(jp3,"3");
		jp0.add(jp4,"4");
		jp0.add(jp5,"5");
		jp0.add(jp6,"6");
		jp0.add(jp7,"7");
		jp0.add(jp8,"8");
		jp0.add(jp9,"9");
		jp0.add(jp10,"10");
		jp11.add(bt1);
		jp11.add(bt2);
		MyEvent();
		myPanel.setLayout(new BorderLayout());
		myPanel.add(jp0,BorderLayout.CENTER);
		myPanel.add(jp11,BorderLayout.SOUTH);
	}
	private void MyEvent()
	{
		bt1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				clo.previous(jp0);
			}
		});
		bt2.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				clo.next(jp0);
			}
		});
	}

}
