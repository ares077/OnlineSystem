package MyMIS;


import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.Serializable;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Login implements Serializable {

	private static final long serialVersionUID=1L;
	//�����ͼ��������Ҫ�����������
	private JFrame fm;
	private JLabel lb1,lb2,lb3,lbsherry;
	private static JLabel lbtime;
	private JButton bt1,bt2;
	private JTextField tf1;
	private JTextField pf2;
	private Checkbox cb1,cb2,cb3;
	private JPanel jp1,jp2,jp3,jp4,jp5,jp6,jp7,jp8,jp9,jp10,jp11,jp12,jp20;
	DataBaseIO dbi;
	//���캯�����ó�ʼ������
	Login() throws InterruptedException
	{
		init();
	}
	public void init() throws InterruptedException
	{
		dbi=new DataBaseIO();
		//����ͼ��(һϵ�е�new)
     	fm=new JFrame("��ӭʹ����ү������ϵͳ");
		lb1=new JLabel("ѧ������ϵͳ",JLabel.CENTER);
		lb1.setFont(new Font("",Font.PLAIN,20));
		lb1.setForeground(Color.BLUE);
		lb2=new JLabel("�˺�:",JLabel.CENTER);
		lb3=new JLabel("����:",JLabel.CENTER);
		lbsherry=new JLabel("designed by ��������2014.04--2014.05",JLabel.CENTER);
		lbtime=new JLabel("",JLabel.CENTER);
		bt1=new JButton("��¼");
		bt1.setFont(new Font("����",Font.PLAIN,14));
		bt2=new JButton("�޸�����");
		bt2.setFont(new Font("����",Font.PLAIN,14));
		tf1=new JTextField(20);
		pf2=new JPasswordField(20);
		CheckboxGroup register=new CheckboxGroup();
		cb1=new Checkbox("����Ա",register,false);
		cb2=new Checkbox("��ʦ",register,false);
		cb3=new Checkbox("ѧ��",register,false);
		jp1=new JPanel();
		jp2=new JPanel();
		jp3=new JPanel();
		jp4=new JPanel();
		jp5=new JPanel();
		jp6=new JPanel();
		jp7=new JPanel();
		jp8=new JPanel();
		jp9=new JPanel();
		jp10=new JPanel();
		jp20=new JPanel();
		jp12=new JPanel(){
			private static final long serialVersionUID = 1L;
			public void paintComponent(Graphics g)
			{
				ImageIcon ima=new ImageIcon(Login.class.getResource("lixiang.jpg"));
				g.drawImage(ima.getImage(),0,0,467,616,jp12);
			}
		};
		jp11=new JPanel();
		//��ʼ��ͼ��(���ô�С,ѡ�񲼾ֹ�����)
		fm.setBounds(200, 100, 1000, 600);
		fm.setLayout(new BorderLayout());
		fm.setIconImage(new ImageIcon(Login.class.getResource("biaotitupian.png")).getImage());
		jp6.setLayout(new GridLayout(10,1));
		//��������ӵ�ͼ����(һЩ�е�add)
		jp1.add(lb1);
		jp2.add(lb2);
		jp2.add(tf1);
		jp3.add(lb3);
		jp3.add(pf2);
		jp4.add(cb1);
		jp4.add(cb2);
		jp4.add(cb3);
		jp5.add(bt1);
		jp5.add(bt2);
		jp6.add(jp7);
		jp6.add(jp8);
		jp6.add(jp9);
		jp6.add(jp1);
		jp6.add(jp2);
		jp6.add(jp3);
		jp6.add(jp4);
		jp6.add(jp5);
		jp6.add(jp10);
		jp6.add(jp11);
		jp20.add(lbsherry);
		jp20.add(lbtime);
		fm.add(jp12,BorderLayout.CENTER);
		fm.add(jp6,BorderLayout.EAST);	
		fm.add(jp20,BorderLayout.SOUTH);
		//���ش����ϵ��¼�(���÷���)
		MyEvent();
		//��ֹ�û��ı��С
		fm.setResizable(false);
		//��ʾͼ��
		fm.setVisible(true);
		tf1.setText("1001");
		pf2.setText("123456");
		fm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	//��д������
	private void MyEvent()
	{
		fm.addWindowListener(new WindowAdapter(){
			public void windowClosing(WindowEvent e)
			{
				try {
					dbi.connClose();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.exit(0);
			}
		});
		bt1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				if(cb1.getState())
				{
						if(dbi.isRegister("admin", tf1.getText(), pf2.getText()))
						{
							new AdminJFrame(tf1.getText());
							try {
								dbi.connClose();
							} catch (SQLException e1) {
								e1.printStackTrace();
							}
							fm.dispose();
						}
						else
						{
							//new AdminJFrame();
							JOptionPane.showMessageDialog(null, "�û������������");
							pf2.setText("");
						}
				}
				else if(cb2.getState())
				{
						if(dbi.isRegister("teacher", tf1.getText(), pf2.getText()))
						{
							new TeacherJFrame(Integer.parseInt(tf1.getText()));
							try {
								dbi.connClose();
							} catch (SQLException e1) {
								e1.printStackTrace();
							}
							fm.dispose();
						}
						else
						{
							JOptionPane.showMessageDialog(null, "�û������������");
							pf2.setText("");
						}
				}
				else if(cb3.getState())
				{
						if(dbi.isRegister("student", tf1.getText(), pf2.getText()))
						{
							new StudentJFrame(Integer.parseInt(tf1.getText()));
							try {
								dbi.connClose();
							} catch (SQLException e1) {
								e1.printStackTrace();
							}
							fm.dispose();
						}
						else
						{
							JOptionPane.showMessageDialog(null, "�û������������");
							pf2.setText("");
						}
				}
				else 
				{
					JOptionPane.showMessageDialog(null, "��ѡ������:");
				}				
			}
		});
		bt2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				if(cb1.getState())
				{
					JOptionPane.showMessageDialog(null, "����ϵ���ʦ��������");
				}
				else if(cb2.getState())
				{
					String str="teacher";
					new ResetPassword(str);	
				}
				else if(cb3.getState())
				{
					String str="stu";
					new ResetPassword(str);
				}
				else
				{
					JOptionPane.showMessageDialog(null, "��ѡ������:");
				}										
			}
		});
	}
	public static void main(String[] args) throws InterruptedException {
		new Login();
		//��ʾʱ��
		Mytime mt=new Mytime();
		mt.start();
		while(true)
		{
			mt.run();
			mt.sleep(1000);
		}
	}
	public static class Mytime extends Thread
	{
		public void run() {
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			Calendar c=Calendar.getInstance();
			lbtime.setText("��ǰʱ��Ϊ:"+df.format(c.getTimeInMillis()));
			lbtime.repaint();
			lbtime.validate();
			}
	}

}
