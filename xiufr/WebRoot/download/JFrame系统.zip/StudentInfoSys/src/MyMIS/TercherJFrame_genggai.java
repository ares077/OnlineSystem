package MyMIS;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class TercherJFrame_genggai {
	private JPanel jp1,jp2,jp3,jp4,jp0;
	private JButton bt1,bt2,bt3,bt4,bt5;
	private JLabel lb1,lb2;
	private JTextField tf1,tf2;
	private JTextArea ta1;
	private JScrollPane sp1;
	DataBaseIO dbi;
	private String str;
	private int id;
	public TercherJFrame_genggai(JPanel myPanel,DataBaseIO dbicanshu,int idcanshu)
	{
		id=idcanshu;
		dbi=dbicanshu;
		jp0=new JPanel();
		jp1=new JPanel();
		jp2=new JPanel();
		jp3=new JPanel();
		jp4=new JPanel();
		tf1=new JTextField(20);
		tf2=new JTextField(20);
		ta1=new JTextArea(5,15);
		ta1.setLineWrap(true);
		sp1=new JScrollPane(ta1);
		sp1.setAutoscrolls(true);
		bt1=new JButton("�޸Ŀγ���");
		bt2=new JButton("�޸ĵص�");
		bt5=new JButton("�޸�ʱ��");
		bt3=new JButton("�޸Ŀγ̼��");
		bt4=new JButton("ȷ���޸�");
		bt4.setVisible(false);
		lb1=new JLabel("�γ̱��:",JLabel.CENTER);
		lb2=new JLabel("",JLabel.CENTER);
		jp1.add(bt1);
		jp1.add(bt2);
		jp1.add(bt5);
		jp1.add(bt3);
		jp0.setLayout(new GridLayout(3,1));
		jp2.add(lb1);
		jp2.add(tf1);
		jp3.add(lb2);
		jp4.add(bt4);
		jp0.add(jp1);
		jp0.add(jp3);
		jp0.add(jp4);
		
		MyEvent();
		myPanel.setLayout(new BorderLayout());
		myPanel.add(jp2,BorderLayout.NORTH);
		myPanel.add(jp0,BorderLayout.CENTER);		
	}

	private void MyEvent()
	{
		//�޸Ŀγ���
		bt1.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(tf1.getText().isEmpty())
				{
					JOptionPane.showMessageDialog(null, "������γ���");
				}
				else
				{
					try {
						if(dbi.isexitedteacherselectcourse(tf1.getText(), id))
						{
							try
							{
								String tr1="course";
								ResultSet rs=dbi.selectone(tr1, tf1.getText());		
								if(rs.next())
								{
									tf2.setText(rs.getNString("coursename"));
									jp3.removeAll();
									str="coursename";
									bt4.setVisible(true);
									jp3.add(lb2);
									jp3.add(tf2);
									lb2.setText("�¿γ���:");
									jp3.setVisible(true);
									jp0.repaint();
									jp0.validate();
								}
								else
								{
									JOptionPane.showMessageDialog(null, "Error,������");
								}
							}catch(SQLException ee)
							{
								JOptionPane.showMessageDialog(null, ee);
								System.out.print(ee);
							}catch(Exception ee2)
							{
								JOptionPane.showMessageDialog(null, ee2);
								System.out.print(ee2);
							}
							
						}else
						{
							JOptionPane.showMessageDialog(null, "��ûѡ���ſΣ������޸�");
						}
					} catch (HeadlessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
			}
		});
		//�޸��Ͽεص�
		bt2.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(tf1.getText().isEmpty())
				{
					JOptionPane.showMessageDialog(null, "������γ���");
				}
				else
				{
					try {
						if(dbi.isexitedteacherselectcourse(tf1.getText(), id))
						{
							
							try
							{
								String tr1="course";
								ResultSet rs=dbi.selectone(tr1, tf1.getText());		
								if(rs.next())
								{
									tf2.setText(rs.getNString("courseadress"));
									jp3.removeAll();
									str="courseadress";
									bt4.setVisible(true);
									jp3.add(lb2);
									jp3.add(tf2);
									lb2.setText("�¿γ̵ص�:");
									jp3.setVisible(true);
									jp0.repaint();
									jp0.validate();
								}
								else
								{
									JOptionPane.showMessageDialog(null, "Error,������");
								}
							}catch(SQLException ee)
							{
								JOptionPane.showMessageDialog(null, ee);
								System.out.print(ee);
							}catch(Exception ee2)
							{
								JOptionPane.showMessageDialog(null, ee2);
								System.out.print(ee2);
							}
						}
						else
						{
							JOptionPane.showMessageDialog(null, "��ûѡ���ſΣ������޸�");
						}
					} catch (HeadlessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
		//�޸��Ͽ�ʱ��
				bt5.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						if(tf1.getText().isEmpty())
						{
							JOptionPane.showMessageDialog(null, "������γ���");
						}
						else
						{
							try {
								if(dbi.isexitedteacherselectcourse(tf1.getText(), id))
								{
									
									try
									{
										String tr1="course";
										ResultSet rs=dbi.selectone(tr1, tf1.getText());		
										if(rs.next())
										{
											tf2.setText(rs.getNString("courseintro"));
											jp3.removeAll();
											str="courseintro";
											bt4.setVisible(true);
											jp3.add(lb2);
											jp3.add(tf2);
											lb2.setText("�¿γ�ʱ��:");
											jp3.setVisible(true);
											jp0.repaint();
											jp0.validate();
										}
										else
										{
											JOptionPane.showMessageDialog(null, "Error,������");
										}
									}catch(SQLException ee)
									{
										JOptionPane.showMessageDialog(null, ee);
										System.out.print(ee);
									}catch(Exception ee2)
									{
										JOptionPane.showMessageDialog(null, ee2);
										System.out.print(ee2);
									}
								}
								else
								{
									JOptionPane.showMessageDialog(null, "��ûѡ���ſΣ������޸�");	
								}
							} catch (HeadlessException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (SQLException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
					}
				});
		//�޸Ŀγ̼��
		bt3.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						if(tf1.getText().isEmpty())
						{
							JOptionPane.showMessageDialog(null, "������γ���");
						}
						else
						{
							try {
								if(dbi.isexitedteacherselectcourse(tf1.getText(), id))
								{
								
									
									try
									{
										String tr1="course";
										ResultSet rs=dbi.selectone(tr1, tf1.getText());		
										if(rs.next())
										{
											ta1.setText(rs.getNString("courseaview"));
											jp3.removeAll();
											str="courseaview";
											bt4.setVisible(true);
											jp3.add(lb2);
											jp3.add(sp1);
											lb2.setText("�¿γ̼��:");
											jp3.setVisible(true);
											jp0.repaint();
											jp0.validate();
										}
										else
										{
											JOptionPane.showMessageDialog(null, "Error,������");
										}
									}catch(SQLException ee)
									{
										JOptionPane.showMessageDialog(null, ee);
										System.out.print(ee);
									}catch(Exception ee2)
									{
										JOptionPane.showMessageDialog(null, ee2);
										System.out.print(ee2);
									}
								}
								else
								{
									JOptionPane.showMessageDialog(null, "��ûѡ���ſΣ������޸�");
								}
							} catch (HeadlessException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (SQLException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
						
					}
				});
		//���γ̱�ŵĺϷ���
		
		//д�����ݿ�
		bt4.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				if(str=="coursename")
				{
					try {
						if(dbi.isaltercourse(str, tf1.getText(), tf2.getText()))
						{
							JOptionPane.showMessageDialog(null, "�޸ĳɹ�");
							tf1.setText("");
							tf2.setText("");
							bt4.setVisible(false);
							jp3.setVisible(false);
							
						}
						else
						{
							JOptionPane.showMessageDialog(null, "Eror,�����û���");
						}
					} catch (HeadlessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
				else if(str=="courseadress")
				{
					try {
						if(dbi.isaltercourse(str, tf1.getText(), tf2.getText()))
						{
							JOptionPane.showMessageDialog(null, "�޸ĳɹ�");
							tf1.setText("");
							tf2.setText("");
							bt4.setVisible(false);
							jp3.setVisible(false);
						}
						else
						{
							JOptionPane.showMessageDialog(null, "Eror,�����û���");
						}
					} catch (HeadlessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				else if(str=="courseaview")
				{
					try {
						if(dbi.isaltercourse(str, tf1.getText(), ta1.getText()))
						{
							JOptionPane.showMessageDialog(null, "�޸ĳɹ�");
							tf1.setText("");
							ta1.setText("");
							bt4.setVisible(false);
							jp3.setVisible(false);
						}
						else
						{
							JOptionPane.showMessageDialog(null, "Eror,����γ���");
						}
					} catch (HeadlessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
				else if(str=="courseintro"){
					try {
						if(dbi.isaltercourse(str, tf1.getText(), tf2.getText()))
						{
							JOptionPane.showMessageDialog(null, "�޸ĳɹ�");
							tf1.setText("");
							tf2.setText("");
							bt4.setVisible(false);
							jp3.setVisible(false);
						}
						else
						{
							JOptionPane.showMessageDialog(null, "Eror,�����û���");
						}
					} catch (HeadlessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
				}
				else{}
			}
		});
	}


}
