package MyMIS;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class AdminJFrame_alterts {
	private JLabel lb1,lb2,lb3,lb4,lb5,lb6;
	private JTextField tf1;
	private JPasswordField pf1,pf2;
	private JButton bt1;
	private JPanel jp[];
	Regex rg;
	DataBaseIO dbi;
	private String str;
	private String id;
	public AdminJFrame_alterts(String str1,JPanel myPanel,DataBaseIO dbicanshu,String idcs)
	{
		id=idcs;
		str=str1;
		dbi=dbicanshu;
		rg=new Regex();
		lb1=new JLabel("ѧ����:      ",JLabel.CENTER);
		lb2=new JLabel("������:      ",JLabel.CENTER);
		lb3=new JLabel("�ٴ�ȷ��:",JLabel.CENTER);
		lb4=new JLabel("");
		lb5=new JLabel("");
		lb6=new JLabel("");
		tf1=new JTextField(20);
		pf1=new JPasswordField(20);
		pf2=new JPasswordField(20);
		bt1=new JButton("ȷ���޸�");
		for(int i=0;i<13;i++)
		{
			if(i==0)
			{
				 jp=new JPanel[13];		
			}
			jp[i]=new JPanel();
		}
		if(str=="teacher")
		{
			lb1.setText("��ʦ��:      ");
		}
		jp[0].setLayout(new GridLayout(4,2));
		jp[1].add(lb1);
		jp[1].add(tf1);
		jp[2].add(lb2);
		jp[2].add(pf1);
		jp[3].add(lb3);
		jp[3].add(pf2);
		jp[4].add(bt1);
		jp[0].add(jp[1]);
		jp[0].add(lb4);
		jp[0].add(jp[2]);
		jp[0].add(lb5);
		jp[0].add(jp[3]);
		jp[0].add(lb6);
		jp[0].add(jp[4]);
		jp[0].add(jp[5]);
		jp[6].setLayout(new GridLayout(3,1));
		jp[6].add(jp[7]);
		jp[6].add(jp[0]);
		jp[6].add(jp[8]);
		MyEvent();
		myPanel.setLayout(new BorderLayout());
		myPanel.add(jp[6],BorderLayout.WEST);
			
	}
	private void MyEvent()
	{
		//��������ѧ�Ž�ʦ���Ƿ�Ϸ�
			tf1.addFocusListener(new FocusAdapter()
			{
				public void focusLost(FocusEvent e)
				{
					if(rg.idisvalid(tf1.getText()))
					{
						lb4.setText("��");
					}
					else
					{
						if(str=="student")
						{
							lb4.setText("ѧ�Ų��Ϸ�");
						}
						else
						{
							lb4.setText("��ʦ�Ų��Ϸ�");
						}
					}
				}
			});
			pf1.addMouseListener(new MouseAdapter()
			{
				public void mouseEntered(MouseEvent e)
				{
					if(rg.idisvalid(tf1.getText()))
					{
						lb4.setText("��");
					}
					else
					{
						if(str=="student")
						{
							lb4.setText("ѧ�Ų��Ϸ�");
						}
						else
						{
							lb4.setText("��ʦ�Ų��Ϸ�");
						}
					}
				}
			});
	    //�������������Ƿ�Ϸ�
			pf1.addFocusListener(new FocusAdapter()
			{
				@SuppressWarnings("deprecation")
				public void focusLost(FocusEvent e)
				{
					if(rg.pwisvalid(pf1.getText()))
					{
						lb5.setText("��");
					}
					else
					{
						lb5.setText("�������6-20λ");
					}
				}
			});
			pf2.addMouseListener(new MouseAdapter()
			{
				@SuppressWarnings("deprecation")
				public void mouseEntered(MouseEvent e)
				{
					if(rg.pwisvalid(pf1.getText()))
					{
						lb5.setText("��");
					}
					else
					{
						lb5.setText("�������6-20λ");
					}
				}
			});
		//������������Ƿ���ͬ
			bt1.addMouseListener(new MouseAdapter()
			{
				@SuppressWarnings("deprecation")
				public void mouseEntered(MouseEvent e)
				{
					if(pf1.getText().equals(pf2.getText()))
					{
						lb6.setText("��");
					}
					else
					{
						lb6.setText("�������벻ͬ");
						pf1.setText("");
						pf2.setText("");
					}
				}
			});
		//д�����ݿ�
			bt1.addActionListener(new ActionListener()
			{
				@SuppressWarnings("deprecation")
				public void actionPerformed(ActionEvent e)
				{
					if(tf1.getText().isEmpty()||pf1.getText().isEmpty()||pf2.getText().isEmpty())
					{
						JOptionPane.showMessageDialog(null, "��д�д���");
					}
					else
					{
						try {
							if(dbi.isadminalterpw(str, tf1.getText(), pf1.getText()))
							{
								JOptionPane.showMessageDialog(null, "�޸ĳɹ�");
								tf1.setText("");
								pf1.setText("");
								pf2.setText("");
								lb4.setText("");
								lb5.setText("");
								lb6.setText("");
							}
							else
							{
								JOptionPane.showMessageDialog(null, "Error,û���û�");
								tf1.setText("");
								pf1.setText("");
								pf2.setText("");
								lb4.setText("");
								lb5.setText("");
								lb6.setText("");
							}
						} catch (HeadlessException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						} catch (SQLException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
			});

	}
	

}
