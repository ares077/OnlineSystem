package MyMIS;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class StudentJFrame_fankuiinfo {
	private JLabel lb1;
	private JTextArea ta1;
	private JScrollPane sp1;
	private JButton bt1,bt2;
	private JPanel jp1,jp2;
	DataBaseIO dbi;
	private int id;
	public StudentJFrame_fankuiinfo(JPanel myPanel,DataBaseIO dbicanshu,int ids)
	{
		id=ids;
		dbi=dbicanshu;
		lb1=new JLabel("�����±�������Ҫ��������Ϣ",JLabel.CENTER);
		ta1=new JTextArea(20,20);
		ta1.setAutoscrolls(true);
		sp1=new JScrollPane();
		ta1.add(sp1);
		sp1.setAutoscrolls(true);
		jp1=new JPanel();
		jp2=new JPanel();
		bt1=new JButton("����");
		bt2=new JButton("ȷ���ύ");
		jp1.add(lb1);
		jp1.add(bt1);
		jp1.add(bt2);
		jp2.add(ta1);
		myPanel.setLayout(new BorderLayout());
		myPanel.add(jp1,BorderLayout.NORTH);
		myPanel.add(jp2,BorderLayout.CENTER);
		myEvent();
	    
		
		
	}
	private void myEvent()
	{
		//�������
		bt1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				ta1.setText("");
			}
		});
		//�ύ����
		bt2.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				if(ta1.getText().length()<=10)
				{
					JOptionPane.showMessageDialog(null, "�������һЩ����");
				}else
				{
					String str1="student"+id+":";
					RandomAccessFile raf;
					try {
						
						raf = new RandomAccessFile("studentfankui.txt","rw");
						raf.seek(raf.length());
						raf.writeBytes(str1+ta1.getText()+"\r\n");
						raf.close();
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}
				
					
					JOptionPane.showMessageDialog(null, "�ύ�ɹ�");
					ta1.setText("");
				}
				
			}
		});
	}


}
