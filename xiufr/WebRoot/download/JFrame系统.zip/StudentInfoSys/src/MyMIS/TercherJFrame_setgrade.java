package MyMIS;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import com.mysql.jdbc.ResultSetMetaData;

public class TercherJFrame_setgrade {
	private JLabel lb1,lb2,lb3,lb4;
	private JTextField tf1,tf2,tf3;
	private JButton bt1;
	private int id;
	DataBaseIO dbi;
	private JPanel jp[],jp2;
	private JScrollPane scrollpane1;
	public TercherJFrame_setgrade(JPanel myPanel,DataBaseIO dbicanshu,int idcanshu)
	{
		id=idcanshu;
		dbi=dbicanshu;
		jp2=new JPanel();
		for(int i=0;i<15;i++)
		{
			if(i==0)
			{
				jp=new JPanel[15];
			}
			jp[i]=new JPanel();
		}
		lb1=new JLabel("ѧ����",JLabel.CENTER);
		lb2=new JLabel("�γ̺�",JLabel.CENTER);
		lb4=new JLabel("�ɼ�",JLabel.CENTER);
		lb3=new JLabel("ȫ��ѧ����Ϣ���ұ�",JLabel.CENTER);
		bt1=new JButton("ȷ��");
		tf1=new JTextField(20);
		tf2=new JTextField(20);
		tf3=new JTextField(20);
		jp[0].setLayout(new GridLayout(6,1));
		jp[1].add(lb1);
		jp[1].add(tf1);
		jp[2].add(lb2);
		jp[2].add(tf2);
		jp[3].add(lb4);
		jp[3].add(tf3);
		jp[4].add(bt1);
		jp[5].add(lb3);
		jp[0].add(jp[10]);
		jp[0].add(jp[2]);
		jp[0].add(jp[1]);
		jp[0].add(jp[3]);
		jp[0].add(jp[4]);
		jp[0].add(jp[5]);
		SetData2();
		MyEvent();
		myPanel.setLayout(new BorderLayout());
		myPanel.add(jp[0],BorderLayout.WEST);
		myPanel.add(jp2,BorderLayout.CENTER);		
	}
	private void SetData2()
	{
		if(scrollpane1!=null)
		{
			jp2.remove(scrollpane1);
		}
		try{
			ResultSet rs=dbi.returnstudentcanbenote2222222222222(id);
			if(rs.next())
			{
				rs.previous();
				ResultSetMetaData rsmd=(ResultSetMetaData) rs.getMetaData();
				Vector<String> columnames= new Vector<String>();
				Vector<Vector<String>> data=new Vector<Vector<String>>();
				columnames.add("�γ̱��");
				columnames.add("ѧ�����");
				columnames.add("�ɼ�");	
				while(rs.next())
				{
					Vector<String> v=new Vector<String>();
					for(int i=0;i<rsmd.getColumnCount();i++)
					{
						v.add(rs.getString(i+1));
					}
					data.add(v);
				}
				JTable table=new JTable(data,columnames);
				scrollpane1=new JScrollPane(table);
				jp2.add(scrollpane1);
				jp2.repaint();
				jp2.validate();		
			}
			else
			{
				JOptionPane.showMessageDialog(null, "������");
				if(scrollpane1!=null)
				{
					jp2.remove(scrollpane1);
					jp2.repaint();
				}
			}}
			catch(SQLException ee)
			{
				JOptionPane.showMessageDialog(null, ee);
				System.out.print(ee);
			}catch(Exception ee2)
			{
				JOptionPane.showMessageDialog(null, ee2);
				System.out.print(ee2);
			}
	}
	public void MyEvent()
	{
		bt1.addMouseListener(new MouseAdapter(){
			public void mouseEntered(MouseEvent e)
			{
				if(!new Regex().idisvalid(tf1.getText()))
				{
					tf1.setText("");
					JOptionPane.showMessageDialog(null, "��������ѧ����ѧ��");
				}
				if(!new Regex().courseidisvalis(tf2.getText()))
				{
					tf2.setText("");
					JOptionPane.showMessageDialog(null, "��������γ̺�");
				}
				if(!new Regex().gradeisvaled(tf3.getText()))
				{
					tf3.setText("");
					JOptionPane.showMessageDialog(null, "����������ɼ�");
				}
			}
		});
		bt1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				if(tf1.getText().length()==0||tf2.getText().length()==0||tf3.getText().length()==0)
				{
					JOptionPane.showMessageDialog(null, "����������");				
				}
				else
				{
					int stuid=Integer.parseInt(tf1.getText());
					int gra=Integer.parseInt(tf3.getText());
					try {
						if(dbi.teachersetgrade(stuid, tf2.getText(),gra ))
						{
							JOptionPane.showMessageDialog(null, "¼��ɹ�");
							tf1.setText("");
							tf2.setText("");
							tf3.setText("");
							SetData2();
						}else
						{
							JOptionPane.showMessageDialog(null, "�����������Ϣ");
						}
					} catch (HeadlessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});

	}

}
