package MyMIS;

import java.awt.BorderLayout;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import com.mysql.jdbc.ResultSetMetaData;

public class StudentJFrame_jiaoxuepingjia {
	private JLabel lb1,lb2,lb3;
	private JPanel jp[],jp2;
	private JScrollPane scrollpane;
	private JButton bt1;
	private JTextField tf1;
	private JCheckBox cb2[];
	private Checkbox cb[];
	DataBaseIO dbi;
	private int id;
	public StudentJFrame_jiaoxuepingjia (JPanel myPanel,DataBaseIO dbicanshu,int ids)
	{
		id=ids;
		dbi=dbicanshu;
		lb1=new JLabel("�γ���",JLabel.CENTER);
		lb2=new JLabel("�ۺ�����:         ",JLabel.CENTER);
		lb3=new JLabel("��ʦ����:         ",JLabel.CENTER);
		tf1=new JTextField(20);
		bt1=new JButton("ȷ��");
		jp2=new JPanel();
		for(int i=0;i<15;i++)
		{
			if(i==0)
			{
				jp=new JPanel[15];
			}
			jp[i]=new JPanel();
		}
		CheckboxGroup cbp=new CheckboxGroup();
		for(int i=0;i<15;i++)
		{
			if(i==0)
			{
				cb=new Checkbox[15];
				cb2=new JCheckBox[15];
			}
			cb2[i]=new JCheckBox();
		}
		SetData();
		myEvent();
		cb[0]=new Checkbox("0.5",cbp,false);
		cb[1]=new Checkbox("1",cbp,false);
		cb[2]=new Checkbox("1.5",cbp,false);
		cb[3]=new Checkbox("2",cbp,false);
		cb[4]=new Checkbox("2.5",cbp,false);
		cb[5]=new Checkbox("3",cbp,false);
		cb[6]=new Checkbox("3.5",cbp,false);
		cb[7]=new Checkbox("4",cbp,false);
		cb[8]=new Checkbox("4.5",cbp,false);
		cb[9]=new Checkbox("5",cbp,false);
		cb[10]=new Checkbox("0",cbp,false);
		cb2[0].setText("��ѧ�̹�����");
		cb2[1].setText("ֻ����ppt");
		cb2[2].setText("����������Ҳ��");
		cb2[3].setText("����������ѧ��");
		cb2[4].setText("����ѡ��");
		jp[1].add(lb1);
		jp[1].add(tf1);
		jp[2].setLayout(new GridLayout(2,1));
		jp[4].add(lb2);
		jp[4].add(cb[10]);
		jp[4].add(cb[0]);
		jp[4].add(cb[1]);
		jp[4].add(cb[2]);
		jp[5].add(cb[3]);
		jp[4].add(cb[4]);
		jp[5].add(cb[5]);
		jp[5].add(cb[6]);
		jp[5].add(cb[7]);
		jp[5].add(cb[8]);
		jp[5].add(cb[9]);
		jp[2].add(jp[4]);
		jp[2].add(jp[5]);
		jp[3].setLayout(new GridLayout(2,1));
		jp[6].add(lb3);
		jp[6].add(cb2[0]);
		jp[6].add(cb2[1]);
		jp[7].add(cb2[2]);
		jp[7].add(cb2[3]);
		jp[7].add(cb2[4]);
		jp[3].add(jp[6]);
		jp[3].add(jp[7]);
		jp[0].setLayout(new GridLayout(4,1));
		jp[0].add(jp[1]);
		jp[0].add(jp[2]);
		jp[0].add(jp[3]);
		jp[0].add(bt1);
		myPanel.setLayout(new BorderLayout());
		myPanel.add(jp[0],BorderLayout.WEST);
		myPanel.add(jp2,BorderLayout.EAST);

	
	}
	public void SetData()
	{
		if(scrollpane!=null)
		{
			jp2.remove(scrollpane);
		}
		try{
			ResultSet rs=dbi.returnstudentnote2222222222222232323232(id);
			if(rs.next())
			{
				rs.previous();
				ResultSetMetaData rsmd=(ResultSetMetaData) rs.getMetaData();
				Vector<String> columnames= new Vector<String>();
				Vector<Vector<String>> data=new Vector<Vector<String>>();
				columnames.add("�γ̱��");
				columnames.add("�γ�����");
				columnames.add("�ɼ�");	
				columnames.add("��ѧ����");	
				columnames.add("ѧ������");	
				while(rs.next())
				{
					Vector<String> v=new Vector<String>();
					for(int i=0;i<rsmd.getColumnCount();i++)
					{
						v.add(rs.getString(i+1));
					}
					data.add(v);
				}
				JTable table=new JTable(data,columnames);
				scrollpane=new JScrollPane(table);
				jp2.add(scrollpane);
				jp2.validate();		
			}
			else
			{
				JOptionPane.showMessageDialog(null, "������");
				if(scrollpane!=null)
				{
					jp2.remove(scrollpane);
					jp2.repaint();
				}
			}}
			catch(SQLException ee)
			{
				JOptionPane.showMessageDialog(null, ee);
				System.out.print(ee);
			}catch(Exception ee2)
			{
				JOptionPane.showMessageDialog(null, ee2);
				System.out.print(ee2);
			}
	}
	public void myEvent()
	{
		bt1.addMouseListener(new MouseAdapter(){
			public void mouseEntered(MouseEvent e)
			{
				if(!new Regex().courseidisvalis(tf1.getText()))
				{
					JOptionPane.showMessageDialog(null, "�γ̺Ų��԰�");
					tf1.setText("");
				}
			}
		});
		bt1.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				boolean b=ischecked();
				if(tf1.getText().length()==0||!b)
				{
					JOptionPane.showMessageDialog(null, "�γ̺ź����ֱ���");
				}
				else{
					try {
						if(dbi.isexisturselectcourse(tf1.getText(),id))
						{
							String chebo=whoischecked();
							String mark=getpingjia();						
							if(dbi.xuehengpingjia(id, tf1.getText(), chebo, mark))
							{
								JOptionPane.showMessageDialog(null, "���۳ɹ�");
								SetData();
							}
							else
							{
								JOptionPane.showMessageDialog(null, "Eror��1992");
							}
						}
						else
						{	
							JOptionPane.showMessageDialog(null, "ûѡ���ſΣ��������۰�");
						
						}
					} catch (HeadlessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
			}
		});
	}
	public boolean ischecked()
	{
		for(int i=0;i<=10;i++)
		{
			if(cb[i].getState())
			{
				return true;
			}
		}
		return false;
	}
	public String whoischecked()
	{
		for(int i=0;i<=10;i++)
		{
			if(cb[i].getState())
			{
				return cb[i].getLabel();
			}
		}
		String aa="Error 0";
		return aa;
	}
	public String getpingjia()
	{
		StringBuilder mb= new StringBuilder();
		if(cb2[0].isSelected())
		{
			mb.append(cb2[0].getLabel());
		}
		if(cb2[1].isSelected())
		{
			mb.append(cb2[1].getLabel());
		}
		if(cb2[2].isSelected())
		{
			mb.append(cb2[2].getLabel());
		}
		if(cb2[3].isSelected())
		{
			mb.append(cb2[3].getLabel());
		}
		if(cb2[4].isSelected())
		{
			mb.append(cb2[4].getLabel());
		}
		String str=mb.toString();
		return str;
	}
	

}
