package MyMIS;

import java.awt.BorderLayout;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import com.mysql.jdbc.ResultSetMetaData;

public class TeacherJFrame_selectallinfo {
	//SELECT course.courseid,course.coursename,teacherlevel from teacherselect,course where teacherselect.courseid=course.courseid and teacherselect.teacherid='1001';
    private JPanel jp1,jp2;
    DataBaseIO dbi;
    private int id;
    private JLabel lb1;
    private JScrollPane scrollpane;
    public TeacherJFrame_selectallinfo(JPanel myPanel,DataBaseIO dbicanshu,int idcanshu)
    {
    	jp1=new JPanel();
    	jp2=new JPanel();
    	
    	dbi=dbicanshu;
    	id=idcanshu;
    	lb1=new JLabel("�������ڵĿγ�����",JLabel.CENTER);
    	if(scrollpane!=null)
		{
			jp2.remove(scrollpane);
		}
		try{
			ResultSet rs=dbi.returnallteacherscourseinfo(id);
			if(rs.next())
			{
				rs.previous();
				ResultSetMetaData rsmd=(ResultSetMetaData) rs.getMetaData();
				Vector<String> columnames= new Vector<String>();
				Vector<Vector<String>> data=new Vector<Vector<String>>();
				columnames.add("�γ̱��");
				columnames.add("�γ�����");
				columnames.add("��ѧЧ��");
				columnames.add("��ѧ����");	
				while(rs.next())
				{
					Vector<String> v=new Vector<String>();
					for(int i=0;i<rsmd.getColumnCount();i++)
					{
						v.add(rs.getString(i+1));
					}
					data.add(v);
				}
				JTable table=new JTable(data,columnames);
				scrollpane=new JScrollPane(table);
				jp2.add(scrollpane);
				jp2.validate();		
			}
			else
			{
				JOptionPane.showMessageDialog(null, "������");
				if(scrollpane!=null)
				{
					jp2.remove(scrollpane);
					jp2.repaint();
				}
			}}
			catch(SQLException ee)
			{
				JOptionPane.showMessageDialog(null, ee);
				System.out.print(ee);
			}catch(Exception ee2)
			{
				JOptionPane.showMessageDialog(null, ee2);
				System.out.print(ee2);
			}
		jp1.add(lb1);
		myPanel.setLayout(new BorderLayout());
		myPanel.add(jp1,BorderLayout.NORTH);
		myPanel.add(jp2,BorderLayout.CENTER);
    }
}
