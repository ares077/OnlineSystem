package cobragame;

public class Cobra {
	Cell[] cells;
	public final static int LEFT=0;
	public final static int RIGHT=1;
	public final static int UP=2;
	public final static int DOWN=3;
	public int direction=UP;
	public int getDirection() {
		return direction;
	}
	public void setDirection(int direction) {
		this.direction = direction;
	}
	public Cobra(){
		cells=new Cell[5];
		cells[0]=new Cell(7,14);
		cells[1]=new Cell(7,15);
		cells[2]=new Cell(7,16);
		cells[3]=new Cell(7,17);
		cells[4]=new Cell(7,18);
	}
	void moveLeft(){
		direction=LEFT;
		  copyCells();
		cells[0].moveLeft();
	}
   void moveUp(){
	   direction=UP;
	   copyCells();
	   cells[0].moveUp();
   }
   void moveRight(){
	   direction=RIGHT;
	   copyCells();
	   cells[0].moveRight();
   }
   void moveDown(){
	   direction=DOWN;
	   copyCells();
	   cells[0].moveDown();
   }
	void copyCells(){
		for(int i=cells.length-1;i>=1;i--){
			cells[i].setHeng(cells[i-1].getHeng());
			cells[i].setShu(cells[i-1].getShu());
		}
	}
}
