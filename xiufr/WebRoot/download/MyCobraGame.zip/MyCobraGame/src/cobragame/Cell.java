package cobragame;
/**
 * 图形的基类，表示一个一个的格子
 * @author Xiang Li
 * @version 1.0
 * @since 1.6
 */

public class Cell {
	private int heng;
	private int shu;
	public int getHeng() {
		return heng;
	}
	public void setHeng(int heng) {
		this.heng = heng;
	}
	public int getShu() {
		return shu;
	}
	public void setShu(int shu) {
		this.shu = shu;
	}
	public Cell(int heng, int shu) {
		this.heng = heng;
		this.shu = shu;
	}
	public void moveLeft(){heng--;}
	public void moveRight(){heng++;}
	public void moveUp(){shu--;}
	public void moveDown(){shu++;}

}
