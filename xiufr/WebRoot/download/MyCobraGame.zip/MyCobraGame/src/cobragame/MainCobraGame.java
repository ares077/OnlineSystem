package cobragame;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Arrays;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;



public class MainCobraGame extends JPanel{
	private static final long serialVersionUID = 1L;
	public static final int JFWIDTH=700;
	public static final int JFHEIFHT=550;
	private int state;
	public static final int RUNNING=0;
	public static final int PAUSE=1;
	public static final int GAME_OVER=2;
	public static final int HENG=20;
	public static final int SHU=40;
	public static final int Cell_SIZE=10;
	private int[][] wall=new int[HENG][SHU];
	private Cobra cobra;
	private Cell cell1,cell2,cell3;
	private int score;
	private String life="'S' to Restart";
	private String lifep="'P' to Pause";
	private String lifeq="'Q' to Quit";
	private String lifec="'C' to Continue";
	private Cell lastCell;
	public MainCobraGame(){
		this.addKeyListener(new KeyAdapter(){
			public void keyPressed(KeyEvent e){
				switch (state) {
				case GAME_OVER:
					if(e.getKeyCode()==KeyEvent.VK_S){
						startAction();
					}
					return;//提前结束方法,不再执行后续方法
				case PAUSE:
					if(e.getKeyCode()==KeyEvent.VK_C){
						state=RUNNING;
					}else if(e.getKeyCode()==KeyEvent.VK_Q){
						int n=JOptionPane.showConfirmDialog(null, "确认退出");
						if(n==JOptionPane.YES_OPTION)System.exit(0);
					}
					return;
				case RUNNING:
					if(e.getKeyCode()==KeyEvent.VK_P){state=PAUSE;}
				}
				switch(e.getKeyCode()){
				case KeyEvent.VK_LEFT:if(cobra.getDirection()!=Cobra.LEFT)moveLeftAction();break;
				case KeyEvent.VK_RIGHT:if(cobra.getDirection()!=Cobra.RIGHT)moveRightAction();break;
				case KeyEvent.VK_UP:if(cobra.getDirection()!=Cobra.UP)moveUpAction();break;
				case KeyEvent.VK_DOWN:if(cobra.getDirection()!=Cobra.DOWN)moveDownAction();break;
				case KeyEvent.VK_Q:state=PAUSE;
					int n=JOptionPane.showConfirmDialog(null, "确认退出？");
					if(n==JOptionPane.YES_OPTION)System.exit(0);
					default:
				}
				repaint();
			}
		});
		this.setFocusable(true);
	}
	protected void moveDownAction() {
		if(cobra.getDirection()==Cobra.UP)return;
		cobra.setDirection(Cobra.DOWN);
	}
	protected void moveUpAction() {
		if(cobra.getDirection()==Cobra.DOWN)return;
		cobra.setDirection(Cobra.UP);
	}
	protected void moveRightAction() {
		if(cobra.getDirection()==Cobra.LEFT)return;
		cobra.setDirection(Cobra.RIGHT);
	}
	protected void moveLeftAction() {
		if(cobra.getDirection()==Cobra.RIGHT)return;
		cobra.setDirection(Cobra.LEFT);
	}
	public void paint(Graphics g){
		g.setColor(Color.gray);
		g.fillRect(0, 0, JFWIDTH, JFHEIFHT);
		cobraInWall();
		paintWall(g);
		paintInfo(g);
	}
	//把有cobra的地方赋值成1
	protected void cobraInWall(){
		for(int i=0;i<HENG;i++){
			for(int j=0;j<SHU;j++){
				wall[i][j]=0;
				for(int x=0;x<cobra.cells.length;x++){
					if(i==cobra.cells[x].getHeng()&&j==cobra.cells[x].getShu()){
						wall[i][j]=1;
						if(x==0){
							wall[i][j]=7;
						}
					}
				}
				if(i==cell1.getHeng()&&j==cell1.getShu()){
					wall[i][j]=2;
				}
				if(i==cell2.getHeng()&&j==cell2.getShu()){
					wall[i][j]=3;
				}
				if(i==cell3.getHeng()&&j==cell3.getShu()){
					wall[i][j]=4;
				}
			}
		}
	}
	protected void paintWall(Graphics g){
		for(int i=0;i<HENG;i++){
			for(int j=0;j<SHU;j++){
				if(wall[i][j]==0){
					g.setColor(Color.black);
					g.drawRect(i*Cell_SIZE, j*Cell_SIZE, Cell_SIZE, Cell_SIZE);
				}else if(wall[i][j]==1){
					g.setColor(Color.magenta);
					g.fillRect(i*Cell_SIZE+1, j*Cell_SIZE+1, Cell_SIZE-1, Cell_SIZE-1);
				}else if(wall[i][j]==7){
					g.setColor(Color.red);
					g.fillRect(i*Cell_SIZE+1, j*Cell_SIZE+1, Cell_SIZE-1, Cell_SIZE-1);
				}else{
					g.setColor(Color.green);
					g.fillRect(i*Cell_SIZE, j*Cell_SIZE, Cell_SIZE, Cell_SIZE);
				}
			}
		}
	}
	protected void paintInfo(Graphics g){
			int x=500;
			int y=30;
			g.setColor(new Color(0x667799));
			Font font=new Font(
					Font.MONOSPACED,Font.BOLD, 28);
			g.setFont(font);
			g.setColor(Color.cyan);
			score=cobra.cells.length;
			g.drawString("Length= "+score,x,y);
			y+=40;
			Font font2=new Font(
					Font.MONOSPACED,Font.BOLD, 15);
			g.setFont(font2);
			g.drawString(life,x,y);
			y+=40;
			g.drawString(lifep,x,y);
			y+=40;
			g.drawString(lifeq,x,y);
			y+=40;
			g.drawString(lifec,x,y);
			y+=40;
			g.drawString("Total= "+HENG*SHU,x,y);
	}
	protected boolean isOutOfBounds(){
		int x=cobra.cells[0].getHeng();
		int y=cobra.cells[0].getShu();
		if(x<0||x>=HENG||y<0||y>=SHU)return true;
		return false;
	}
	protected boolean isConcide(){
		for(int i=0;i<cobra.cells.length;i++){
			int x=cobra.cells[i].getHeng();
			int y=cobra.cells[i].getShu();
			for(int j=0;j<cobra.cells.length;j++){
				if(i==j)continue;
				int x2=cobra.cells[j].getHeng();
				int y2=cobra.cells[j].getShu();
				if(x==x2&&y==y2)return true;
			}
		}
		return false;
	}
	protected void randomNewCell(){
		Random r=new Random();
		while(true){
			int x=r.nextInt(HENG);
			int y=r.nextInt(SHU);
			if(wall[x][y]==0){
				cell1=new Cell(x,y);
				break;
			}
		}
		while(true){
			int x=r.nextInt(HENG);
			int y=r.nextInt(SHU);
			if(wall[x][y]==0){
				cell2=new Cell(x,y);
				break;
			}
		}
		while(true){
			int x=r.nextInt(HENG);
			int y=r.nextInt(SHU);
			if(wall[x][y]==0){
				cell3=new Cell(x,y);
				break;
			}
		}
	}
	protected void addCell(Cell c){
		cobra.cells=Arrays.copyOf(cobra.cells, cobra.cells.length+1);
		int x=lastCell.getHeng();int y=lastCell.getShu();
		cobra.cells[cobra.cells.length-1]=new Cell(x,y);
	}
	private boolean canAdded2(){
		try{
		if(wall[cobra.cells[0].getHeng()][cobra.cells[0].getShu()]==2)return true;
		}catch(Exception e){}
		return false;
	}
	private boolean canAdded3(){
		try{
		if(wall[cobra.cells[0].getHeng()][cobra.cells[0].getShu()]==3)return true;
		}catch(Exception e){}
		return false;
	}
	private boolean canAdded4(){
		try{
		if(wall[cobra.cells[0].getHeng()][cobra.cells[0].getShu()]==4)return true;
		}catch(Exception e){}
		return false;
	}
	public static void main(String[] args) {
		 JFrame jf=new JFrame("七爷开发的贪吃蛇1.0版");
		 MainCobraGame gamePanel=new MainCobraGame();
		 gamePanel.startAction();
			jf.add(gamePanel);
			jf.setBounds(100, 100, JFWIDTH, JFHEIFHT);
			jf.setAlwaysOnTop(true);
			jf.setLocationRelativeTo(null);
			jf.setVisible(true);
			jf.setResizable(false);
			jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			jf.setIconImage(new ImageIcon(MainCobraGame.class.getResource("biaotitupian.png")).getImage());	
	}
	private void startAction() {
		state=RUNNING;
		cobra=new Cobra();
		randomNewCell();
		repaint();
		Timer timer=new Timer();
		timer.schedule(new TimerTask(){
			public void run(){
				lastCell=new Cell(cobra.cells[cobra.cells.length-1].getHeng(),cobra.cells[cobra.cells.length-1].getShu());
				if(state==RUNNING){
						int x=cobra.getDirection();
						switch(x){
						case 0:cobra.moveLeft();break;
						case 1:cobra.moveRight();break;
						case 2:cobra.moveUp();break;
						case 3:cobra.moveDown();break;
						}
				}
				if(canAdded2()){
					addCell(cell1);
					randomNewCell();
				}
				if(canAdded3()){
					addCell(cell2);
					randomNewCell();
				}
				if(canAdded4()){
					addCell(cell3);
					randomNewCell();
				}
				if(isOutOfBounds()||isConcide()){
					state=GAME_OVER;
					int n=JOptionPane.showConfirmDialog(null, "是否重新开始？");
					if(n==JOptionPane.YES_OPTION)startAction();
					this.cancel();
				}
				repaint();
			}
		}, 0, 400);
	}
}
