package com.lixiang.tank;

import java.util.Random;


public abstract class Tank {
	protected Cell[] cells=new Cell[10];
	protected int heng;
	protected int shu;
	protected int hujia;
	protected int direction=3;
	protected int speed=200;
	protected boolean doubleFire=false;
	public Tank(int heng, int shu, int hujia) {
		this.heng = heng;
		this.shu = shu;
		this.hujia = hujia;
	}
	protected boolean isShooted(int h,int s){
		if(h>=(cells[0].getHeng()-1)&&h<(cells[0].getHeng()+2)&&s>=(cells[0].getShu()-1)&&(s<cells[0].getShu()+2))return true;
		return false;
	}
	protected void turnUp(){direction=3;cells[9].setHeng(cells[0].getHeng());cells[9].setShu(cells[0].getShu()-2);}
	protected void turnDown(){direction=1;cells[9].setHeng(cells[0].getHeng());cells[9].setShu(cells[0].getShu()+2);}
	protected void turnLeft(){direction=0;cells[9].setHeng(cells[0].getHeng()-2);cells[9].setShu(cells[0].getShu());}
	protected void turnRight(){direction=2;cells[9].setHeng(cells[0].getHeng()+2);cells[9].setShu(cells[0].getShu());}
	protected void moveLeft(){turnLeft();for(Cell c:cells)c.moveLeft();}
	protected void moveRight(){turnRight();for(Cell c:cells)c.moveRight();}
	protected void moveUp(){turnUp();for(Cell c:cells)c.moveUp();}
	protected void moveDown(){turnDown();for(Cell c:cells)c.moveDown();}
	public int getDirection() {
		return direction;
	}
	public void setDirection(int direction) {
		this.direction = direction;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public int getHujia() {
		return hujia;
	}
	public void setHujia(int hujia) {
		this.hujia = hujia;
	}
	public boolean isDoubleFire() {
		return doubleFire;
	}
	public void setDoubleFire(boolean doubleFire) {
		this.doubleFire = doubleFire;
	}
	
}
class MyTank extends Tank{
	public MyTank(int heng, int shu) {
		super(heng, shu, 1);
		cells[0]=new Cell(heng,shu);
		cells[1]=new Cell(heng-1,shu-1);
		cells[2]=new Cell(heng-1,shu);
		cells[3]=new Cell(heng-1,shu+1);
		cells[4]=new Cell(heng,shu-1);
		cells[5]=new Cell(heng,shu+1);
		cells[6]=new Cell(heng+1,shu-1);
		cells[7]=new Cell(heng+1,shu);
		cells[8]=new Cell(heng+1,shu+1);
		cells[9]=new Cell(heng,shu-2);
	}
}
class EnemyTank extends Tank implements Enemy{
	public EnemyTank(int heng, int shu) {
		super(heng, shu, 1);
		Random r=new Random();
		this.setHujia(r.nextInt(3)+1);
		cells[0]=new Cell(heng,shu);
		cells[1]=new Cell(heng-1,shu-1);
		cells[2]=new Cell(heng-1,shu);
		cells[3]=new Cell(heng-1,shu+1);
		cells[4]=new Cell(heng,shu-1);
		cells[5]=new Cell(heng,shu+1);
		cells[6]=new Cell(heng+1,shu-1);
		cells[7]=new Cell(heng+1,shu);
		cells[8]=new Cell(heng+1,shu+1);
		cells[9]=new Cell(heng,shu+2);
	}

	@Override
	public int getScore() {
		// TODO Auto-generated method stub
		return 5;
	}	
}
class EnemyTank2 extends Tank implements Enemy,Award{
	public EnemyTank2(int heng, int shu) {
		super(heng, shu, 1);
		cells[0]=new Cell(heng,shu);
		cells[1]=new Cell(heng-1,shu-1);
		cells[2]=new Cell(heng-1,shu);
		cells[3]=new Cell(heng-1,shu+1);
		cells[4]=new Cell(heng,shu-1);
		cells[5]=new Cell(heng,shu+1);
		cells[6]=new Cell(heng+1,shu-1);
		cells[7]=new Cell(heng+1,shu);
		cells[8]=new Cell(heng+1,shu+1);
		cells[9]=new Cell(heng,shu+2);
	}

	@Override
	public int getScore() {
		return 5;
	}

	@Override
	public int getType() {
		Random r=new Random();
		return (r.nextInt(3)+1);
	}	
}
