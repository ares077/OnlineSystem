package com.lixiang.tank;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Arrays;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;


public class Test extends JPanel{
	private static final long serialVersionUID = 1L;
	private int state;
	public static final int RUNNING=0;
	public static final int PAUSE=1;
	public static final int GAME_OVER=2;
	public static final int HENGSHU=50;
	public static final int CELL_SIZE=10;
	private SoilWall[] soilWall=new SoilWall[150];
	private Water[] water=new Water[300];
	private Cell[][] wall=new Cell[HENGSHU][HENGSHU];
	protected Tank[] tank=new Tank[8];
	private Bullet[] bullet=new Bullet[10];
	private int score;
	private int life=2;
	private int score2;
	private int life2=2;
	private int index=100;
	private JPanel jp1=new JPanel();
	private JPanel jp2=new JPanel();
 
	
	//构造方法 时间监听
	/**
	 * 
	 */
	/**
	 * 
	 */
	/**
	 * 
	 */
	/**
	 * 
	 */
	/**
	 * 
	 */
	/**
	 * 
	 */
	public Test() {
		jp1.addKeyListener(new KeyAdapter(){
			public void keyPressed(KeyEvent e){
				switch (state) {
				case GAME_OVER:
					if(e.getKeyCode()==KeyEvent.VK_S){
						//restartAction();//游戏重新开始
					}
					return;//提前结束方法,不再执行后续方法
				case PAUSE:
					if(e.getKeyCode()==KeyEvent.VK_C){
						state=RUNNING;
					}else if(e.getKeyCode()==KeyEvent.VK_Q){
						int n=JOptionPane.showConfirmDialog(null, "确认退出");
						if(n==JOptionPane.YES_OPTION)System.exit(0);
					}
					return;
				case RUNNING:
					if(e.getKeyCode()==KeyEvent.VK_P){state=PAUSE;}
				}
				switch(e.getKeyCode()){
				case KeyEvent.VK_LEFT:if(tank[1]!=null)moveLeftAction(tank[1]);break;
				case KeyEvent.VK_RIGHT:if(tank[1]!=null)moveRightAction(tank[1]);break;
				case KeyEvent.VK_UP:if(tank[1]!=null)moveUpAction(tank[1]);break;
				case KeyEvent.VK_DOWN:if(tank[1]!=null)moveDownAction(tank[1]);break;
				//case KeyEvent.VK_A:if(tank[0]!=null)moveLeftAction(tank[0]);break;
				//case KeyEvent.VK_D:if(tank[0]!=null)moveRightAction(tank[0]);break;
				//case KeyEvent.VK_W:if(tank[0]!=null)moveUpAction(tank[0]);break;
				//case KeyEvent.VK_S:if(tank[0]!=null)moveDownAction(tank[0]);break;
				case KeyEvent.VK_F1:life2+=1;break;
				case KeyEvent.VK_F2:life+=1;break;
				case KeyEvent.VK_K:if(tank[0]!=null)tank[0].setSpeed(tank[0].getSpeed()/2);break;
				case KeyEvent.VK_NUMPAD1:if(tank[1]!=null)tank[1].setSpeed(tank[1].getSpeed()/2);break;
				case KeyEvent.VK_F11:if(tank[0]!=null)tank[0].setDoubleFire(true);break;
				case KeyEvent.VK_F12:if(tank[1]!=null)tank[1].setDoubleFire(true);break;
				case KeyEvent.VK_F5:if(life2>0){tank[0]=new MyTank(23,48);life2-=1;break;}break;
				case KeyEvent.VK_F6:if(life>0){tank[1]=new MyTank(27,48);life-=1;break;}break;
				case KeyEvent.VK_NUMPAD0:if(tank[1]!=null){myTank1FireAction1(tank[1]);if(tank[1].doubleFire)myTank1FireAction2(tank[1]);break;}break;
				case KeyEvent.VK_J:if(tank[0]!=null){myTank2FireAction1(tank[0]);if(tank[0].doubleFire)myTank2FireAction2(tank[0]);break;}break;
				case KeyEvent.VK_Q:state=PAUSE;
					int n=JOptionPane.showConfirmDialog(null, "确认退出");
					if(n==JOptionPane.YES_OPTION)System.exit(0);
					default:
				}
				repaint();
			}
		});
		jp1.setFocusable(true);
		this.addKeyListener(new KeyAdapter(){
			public void keyPressed(KeyEvent e){
				switch (state) {
				case GAME_OVER:
					if(e.getKeyCode()==KeyEvent.VK_S){
						//restartAction();//游戏重新开始
					}
					return;//提前结束方法,不再执行后续方法
				case PAUSE:
					if(e.getKeyCode()==KeyEvent.VK_C){
						state=RUNNING;
					}else if(e.getKeyCode()==KeyEvent.VK_Q){
						int n=JOptionPane.showConfirmDialog(null, "确认退出");
						if(n==JOptionPane.YES_OPTION)System.exit(0);
					}
					return;
				case RUNNING:
					if(e.getKeyCode()==KeyEvent.VK_P){state=PAUSE;}
				}
				switch(e.getKeyCode()){
				//case KeyEvent.VK_LEFT:if(tank[1]!=null)moveLeftAction(tank[1]);break;
				//case KeyEvent.VK_RIGHT:if(tank[1]!=null)moveRightAction(tank[1]);break;
				//case KeyEvent.VK_UP:if(tank[1]!=null)moveUpAction(tank[1]);break;
				//case KeyEvent.VK_DOWN:if(tank[1]!=null)moveDownAction(tank[1]);break;
				case KeyEvent.VK_A:if(tank[0]!=null)moveLeftAction(tank[0]);break;
				case KeyEvent.VK_D:if(tank[0]!=null)moveRightAction(tank[0]);break;
				case KeyEvent.VK_W:if(tank[0]!=null)moveUpAction(tank[0]);break;
				case KeyEvent.VK_S:if(tank[0]!=null)moveDownAction(tank[0]);break;
				case KeyEvent.VK_F1:life2+=1;break;
				case KeyEvent.VK_F2:life+=1;break;
				case KeyEvent.VK_K:if(tank[0]!=null)tank[0].setSpeed(tank[0].getSpeed()/2);break;
				case KeyEvent.VK_NUMPAD1:if(tank[1]!=null)tank[1].setSpeed(tank[1].getSpeed()/2);break;
				case KeyEvent.VK_F11:if(tank[0]!=null)tank[0].setDoubleFire(true);break;
				case KeyEvent.VK_F12:if(tank[1]!=null)tank[1].setDoubleFire(true);break;
				case KeyEvent.VK_F5:if(life2>0){tank[0]=new MyTank(23,48);life2-=1;break;}break;
				case KeyEvent.VK_F6:if(life>0){tank[1]=new MyTank(27,48);life-=1;break;}break;
				case KeyEvent.VK_NUMPAD0:if(tank[1]!=null){myTank1FireAction1(tank[1]);if(tank[1].doubleFire)myTank1FireAction2(tank[1]);break;}break;
				case KeyEvent.VK_J:if(tank[0]!=null){myTank2FireAction1(tank[0]);if(tank[0].doubleFire)myTank2FireAction2(tank[0]);break;}break;
				case KeyEvent.VK_Q:state=PAUSE;
					int n=JOptionPane.showConfirmDialog(null, "确认退出");
					if(n==JOptionPane.YES_OPTION)System.exit(0);
					default:
				}
				repaint();
			}
		});
		this.setFocusable(true);
		int i=0;
		for(int s=24;s<=26;s++){
			for(int h=0;h<HENGSHU;h++){
				soilWall[i]=new SoilWall(h,s);
				i++;
			}
		}
		int j=0;
		for(int s=30;s<=33;s++){
			for(int h=5;h<HENGSHU-5;h++){
				water[j]=new Water(h,s);
				j++;
			}
		}
		//System.out.println(j);;/
	}
	//判断是否出界
	private boolean outOfBounds(Tank tank) {
		for(int i=0;i<tank.cells.length-1;i++){
			int h=tank.cells[i].getHeng();
			int s=tank.cells[i].getShu();
			if(h<0||h>=(HENGSHU)||s<0||s>=(HENGSHU))return true;
		}
		return false;
	}
	private boolean outOfBounds(Bullet b) {
		    Cell cell=b;
			int h=cell.getHeng();
			int s=cell.getShu();
			if(h<0||h>=(HENGSHU)||s<0||s>=(HENGSHU))return true;
		return false;
	}
	//检查是否重合
	private boolean concide(Tank tank) {
		for(int i=0;i<tank.cells.length-1;i++){
			int h=tank.cells[i].getHeng();
			int s=tank.cells[i].getShu();
			if(wall[h][s]!=null){
				return true;
			}
		}
		return false;
	}
	private boolean concide(Bullet b) {
	    Cell cell=b;
			int h=cell.getHeng();
			int s=cell.getShu();
			if(wall[h][s]!=null){
				if(wall[h][s] instanceof Water)return false;
				//System.out.println(wall[h][s] instanceof Water);
				return true;
			}
		return false;
	}
	//左移
	void moveLeftAction(Tank tank){
		tank.moveLeft();
		if(outOfBounds(tank)||concide(tank))tank.moveRight();}
	//右移
	void moveRightAction(Tank tank){
		tank.moveRight();
		if(outOfBounds(tank)||concide(tank))tank.moveLeft();}
	//上移
	void moveUpAction(Tank tank){
		tank.moveUp();
		if(outOfBounds(tank)||concide(tank))tank.moveDown();}
	//下移
	void moveDownAction(Tank tank){
		tank.moveDown();		
		if(outOfBounds(tank)||concide(tank))tank.moveUp();}
	//开火
	void myTank1FireAction1(Tank tank){
		if(bullet[0]!=null)return;
		final int direction=tank.getDirection();
		int speed=tank.getSpeed();
		speed=speed<15?15:speed;
		bullet[0]=new Bullet(tank.cells[9].getHeng(),tank.cells[9].getShu());
		final Bullet bu=bullet[0];
		Timer timer = new Timer();
		timer.schedule(new TimerTask(){
			public void run(){
				if(state==RUNNING){
					BulletAction(direction,bu);
					int indexss=enemyTankIsShooted(bullet[0].getHeng(),bullet[0].getShu());
					if(indexss>0){
						bullet[0]=null;
						if(Test.this.tank[1]!=null){
						 switch(indexss){
						 case 1:Test.this.tank[1].setDoubleFire(true);score+=5;break;
						 case 2:Test.this.tank[1].setHujia(Test.this.tank[1].getHujia()+1);score+=5;break;
						 case 3:Test.this.tank[1].setSpeed(Test.this.tank[1].getSpeed()-25);score+=5;break;
						 case 4:life+=1;break;
						 case 5:score+=5;break;
						 }
						 repaint();}
					}
					if(bullet[0]==null){
						this.cancel();
						return;
					}
					if(outOfBounds(bullet[0])||concide(bullet[0])){
						if(outOfBounds(bullet[0])){
							bullet[0]=null;
							this.cancel();
						}else if(concide(bullet[0])){
							int x=bullet[0].getHeng();
							int y=bullet[0].getShu();
							wall[x][y]=null;
							soilWallShooted(x,y);
							bullet[0]=null;
							this.cancel();
						}
					}
				}
				repaint();
			}
		}, 0, speed);
	}
	void myTank1FireAction2(Tank tank){
		if(bullet[1]!=null)return;
		final int direction=tank.getDirection();
		int speed=tank.getSpeed();
		speed=speed<15?15:speed;
		bullet[1]=new Bullet(tank.cells[9].getHeng(),tank.cells[9].getShu());
		final Bullet bu=bullet[1];
		Timer timer = new Timer();
		timer.schedule(new TimerTask(){
			public void run(){
				if(state==RUNNING){
					BulletAction(direction,bu);
					int indexss=enemyTankIsShooted(bullet[1].getHeng(),bullet[1].getShu());
					if(indexss>0){
						bullet[1]=null;
						if(Test.this.tank[1]!=null){
						 switch(indexss){
						 case 1:Test.this.tank[1].setDoubleFire(true);score+=5;break;
						 case 2:Test.this.tank[1].setHujia(Test.this.tank[1].getHujia()+1);score+=5;break;
						 case 3:Test.this.tank[1].setSpeed(Test.this.tank[1].getSpeed()-25);score+=5;break;
						 case 4:life+=1;break;
						 case 5:score+=5;break;
						 }
						 repaint();}
					}
					if(bullet[1]==null){
						this.cancel();
						return;
					}
					if(outOfBounds(bullet[1])||concide(bullet[1])){
						if(outOfBounds(bullet[1])){
							bullet[1]=null;
							this.cancel();
						}else if(concide(bullet[1])){
							int x=bullet[1].getHeng();
							int y=bullet[1].getShu();
							wall[x][y]=null;
							soilWallShooted(x,y);
							bullet[1]=null;
							this.cancel();
						}
					}
				}
				repaint();
			}
		}, speed, speed);
	}
	void myTank2FireAction1(Tank tank){
		if(bullet[2]!=null)return;
		final int direction=tank.getDirection();
		int speed=tank.getSpeed();
		speed=speed<15?15:speed;
		bullet[2]=new Bullet(tank.cells[9].getHeng(),tank.cells[9].getShu());
		final Bullet bu=bullet[2];
		Timer timer = new Timer();
		timer.schedule(new TimerTask(){
			public void run(){
				if(state==RUNNING){
					BulletAction(direction,bu);
					int indexss=enemyTankIsShooted(bullet[2].getHeng(),bullet[2].getShu());
					if(indexss>0){
						bullet[2]=null;
						if(Test.this.tank[0]!=null){
						 switch(indexss){
						 case 1:Test.this.tank[0].setDoubleFire(true);score2+=5;break;
						 case 2:Test.this.tank[0].setHujia(Test.this.tank[0].getHujia()+1);score2+=5;break;
						 case 3:Test.this.tank[0].setSpeed(Test.this.tank[0].getSpeed()-25);score2+=5;break;
						 case 4:life+=1;break;
						 case 5:score2+=5;break;
						 }
						 repaint();}
					}
					if(bullet[2]==null){
						this.cancel();
						return;
					}
					if(outOfBounds(bullet[2])||concide(bullet[2])){
						if(outOfBounds(bullet[2])){
							bullet[2]=null;
							this.cancel();
						}else if(concide(bullet[2])){
							int x=bullet[2].getHeng();
							int y=bullet[2].getShu();
							wall[x][y]=null;
							soilWallShooted(x,y);
							bullet[2]=null;
							this.cancel();
						}
					}
				}
				repaint();
			}
		}, 0, speed);
	}
	void myTank2FireAction2(Tank tank){
		if(bullet[3]!=null)return;
		final int direction=tank.getDirection();
		int speed=tank.getSpeed();
		speed=speed<15?15:speed;
		bullet[3]=new Bullet(tank.cells[9].getHeng(),tank.cells[9].getShu());
		final Bullet bu=bullet[3];
		Timer timer = new Timer();
		timer.schedule(new TimerTask(){
			public void run(){
				if(state==RUNNING){
					BulletAction(direction,bu);
					int indexss=enemyTankIsShooted(bullet[3].getHeng(),bullet[3].getShu());
					if(indexss>0){
						 bullet[3]=null;
						 if(Test.this.tank[0]!=null){
						 switch(indexss){
						 case 1:Test.this.tank[0].setDoubleFire(true);score2+=5;break;
						 case 2:Test.this.tank[0].setHujia(Test.this.tank[0].getHujia()+1);score2+=5;break;
						 case 3:Test.this.tank[0].setSpeed(Test.this.tank[0].getSpeed()-25);score2+=5;break;
						 case 4:life+=1;break;
						 case 5:score2+=5;break;
						 default:
						 }
						 repaint();}
					}
					if(bullet[3]==null){
						this.cancel();
						return;
					}
					if(outOfBounds(bullet[3])||concide(bullet[3])){
						if(outOfBounds(bullet[3])){
							bullet[3]=null;
							this.cancel();
						}else if(concide(bullet[3])){
							int x=bullet[3].getHeng();
							int y=bullet[3].getShu();
							wall[x][y]=null;
							soilWallShooted(x,y);
							bullet[3]=null;
							this.cancel();
						}
					}
				}
				repaint();
			}
		}, speed, speed);
	}
	//地方坦克开火
	void enemyTankFireAction(){
		for(int i=2;i<tank.length-1;i++){
			final int ii=i+2;
			if(bullet[ii]!=null)continue;
			final int direction=tank[i].getDirection();
			int speed=tank[i].getSpeed();
			speed=speed<15?15:speed;
			bullet[ii]=new Bullet(tank[i].cells[9].getHeng(),tank[i].cells[9].getShu());
			final Bullet bu=bullet[ii];
			Timer timer = new Timer();
			timer.schedule(new TimerTask(){
				public void run(){
					if(state==RUNNING){
						BulletAction(direction,bu);
						if(myTankIsShooted(bullet[ii].getHeng(),bullet[ii].getShu()))
						{
							bullet[ii]=null;
						}
						if(bullet[ii]==null){
							this.cancel();
							return;
						}
						if(outOfBounds(bullet[ii])||concide(bullet[ii])){
							if(outOfBounds(bullet[ii])){
								bullet[ii]=null;
								this.cancel();
							}else if(concide(bullet[ii])){
								int x=bullet[ii].getHeng();
								int y=bullet[ii].getShu();
								wall[x][y]=null;
								soilWallShooted(x,y);
								bullet[ii]=null;
								this.cancel();
							}
						}
					}
					repaint();
				}
			}, 0, 100);
		}
	}
	//墙被击中
	protected void soilWallShooted(int x, int y) {
		for(int i=0;i<soilWall.length;i++){
			if(soilWall[i].getHeng()==x&&soilWall[i].getShu()==y){
				SoilWall t=soilWall[i];
				soilWall[i]=soilWall[soilWall.length-1];
				soilWall[soilWall.length-1]=t;
				soilWall=Arrays.copyOf(soilWall, soilWall.length-1);
			}
		}	
	}
	//子弹飞
	protected void BulletAction(int d,Bullet bullet) {
		switch(d)
		{
		case 0:bullet.setHeng(bullet.getHeng()-1);break;
		case 2:bullet.setHeng(bullet.getHeng()+1);break;
		case 3:bullet.setShu(bullet.getShu()-1);break;
		case 1:bullet.setShu(bullet.getShu()+1);break;
		}
	}
	//判断是否打中地方坦克
	private int enemyTankIsShooted(int x,int y){
		for(int i=2;i<=tank.length-1;i++){
			if(tank[i].isShooted(x, y)){
				//System.out.println(tank[i].cells[0].getHeng()+","+tank[i].cells[0].getShu());
				tank[i].setHujia(tank[i].getHujia()-1);
				if(tank[i].getHujia()<=0){
				if(tank[i] instanceof EnemyTank2){
					EnemyTank2 t2=(EnemyTank2) tank[i];
					tank[i]=randomTank();
					repaint();
					return t2.getType();
				}else{
					EnemyTank t=(EnemyTank) tank[i];
					tank[i]=randomTank();
					repaint();
					return t.getScore();
				}}
				return 7;
			}
		}
		return 0;
	}
	//判断子弹是否打中我方tank
	private boolean myTankIsShooted(int x,int y){
		for(int i=0;i<=1;i++){
			if(tank[i]==null)continue;
			if(tank[i].isShooted(x, y)){
				//System.out.println(tank[i].cells[0].getHeng()+","+tank[i].cells[0].getShu());
				tank[i].setHujia(tank[i].getHujia()-1);
				if(tank[i].getHujia()<=0){
					if(i==0){if(life2>0){tank[0]=new MyTank(23,48);life2-=1;}else{tank[0]=null;}}
					else {if(life>0){tank[1]=new MyTank(27,48);life-=1;}else{tank[1]=null;}}
				}
				return true;
			}
		}
		return false;
	}
	//画整个面板
	private void paintWall(Graphics g){
		for(int h=0;h<HENGSHU;h++){
			for(int s=0;s<HENGSHU;s++){
				int x=h*CELL_SIZE;
				int y=s*CELL_SIZE;
				g.setColor(Color.black);
				g.fillRect(x, y, CELL_SIZE, CELL_SIZE);
			}
		}
	}
	//画土墙
	private void paintSoilWall(Graphics g){
		for(int i=0;i<soilWall.length;i++){
			Cell cell=soilWall[i];
			int x=cell.getHeng();
			int y=cell.getShu();
			wall[x][y]=soilWall[i];
			g.setColor(Color.gray);
			g.fill3DRect(x*CELL_SIZE, y*CELL_SIZE, CELL_SIZE, CELL_SIZE, false);
		}
	}
	//画水
	private void paintWater(Graphics g){
		for(int i=0;i<160;i++){
			Cell cell=water[i];
			int x=cell.getHeng();
			int y=cell.getShu();
			wall[x][y]=water[i];
			g.setColor(Color.blue);
			g.fillRect(x*CELL_SIZE, y*CELL_SIZE, CELL_SIZE, CELL_SIZE);
		}
	}
	private void paintBullet(Graphics g){
		for (int i=0;i<bullet.length;i++){
			if(bullet[i]==null)continue;
			Cell cell=bullet[i];
			int x=cell.getHeng()*CELL_SIZE;
			int y=cell.getShu()*CELL_SIZE;
			g.setColor(Color.red);
			g.fill3DRect(x, y, CELL_SIZE, CELL_SIZE, false);
		}
	}
	//画坦克
	private void paintTank(Graphics g) {
		for(int j=0;j<tank.length-1;j++){
			if(tank[j]==null)continue;
			Cell[] cells=tank[j].cells;
			for(int i=0;i<cells.length;i++){
				Cell cell=cells[i];
				int x=cell.getHeng()*CELL_SIZE;
				int y=cell.getShu()*CELL_SIZE;
				if(j==1)g.setColor(Color.yellow);
				else if(j==0)g.setColor(Color.green);
				else {if(tank[j] instanceof EnemyTank2)g.setColor(Color.magenta);
				else if(tank[j].getHujia()>2)g.setColor(Color.darkGray);else if(tank[j].getHujia()>1)g.setColor(Color.lightGray);
				         else g.setColor(Color.cyan);
				}
				g.fill3DRect(x, y, CELL_SIZE, CELL_SIZE, false);	
			}
		}
	}
	//画草
	private void paintGrass(Graphics g){
		for(int h=0;h<HENGSHU;h++){
			for(int s=35;s<=40;s++){
				int x=h*CELL_SIZE;
				int y=s*CELL_SIZE;
				g.setColor(Color.green);
				g.fillRect(x, y, CELL_SIZE-1, CELL_SIZE-1);
			}
		}
	}
	//画出坦克信息
	public void paintTankInfo(Graphics g){
		int x=500;
		int y=30;
		g.setColor(new Color(0x667799));
		Font font=new Font(
				Font.MONOSPACED,Font.BOLD, 28);
		g.setFont(font);
		g.drawString("SCORE:"+score,x,y);
		y+=40;
		g.drawString("LIFE:"+life,x,y);
		y+=40;
		Font font2=new Font(
				Font.MONOSPACED,Font.BOLD, 15);
		g.setFont(font2);
		if(tank[1]!=null)g.drawString("Tank1_huaji:"+tank[1].getHujia(),x,y);
		y+=40;
		if(tank[1]!=null){
			if(tank[1].getSpeed()<15){g.drawString("Tank1_sp:"+"15",x,y);}
			else {g.drawString("Tank1_sp:"+tank[1].getSpeed(),x,y);}
		}
		y+=40;
		if(tank[1]!=null)g.drawString("Tank1_D_F:"+tank[1].isDoubleFire(),x,y);
		y+=80;
		g.setColor(new Color(0x667799));
		Font font3=new Font(
				Font.MONOSPACED,Font.BOLD, 28);
		g.setFont(font3);
		g.drawString("SCORE:"+score2,x,y);
		y+=40;
		g.drawString("LIFE:"+life2,x,y);
		y+=40;
		Font font4=new Font(
				Font.MONOSPACED,Font.BOLD, 15);
		g.setFont(font4);
		if(tank[0]!=null)g.drawString("Tank2_huaji:"+tank[0].getHujia(),x,y);
		y+=40;
		if(tank[0]!=null){
			if(tank[0].getSpeed()<15){g.drawString("Tank2_sp:"+"15",x,y);}
			else {g.drawString("Tank2_sp:"+tank[0].getSpeed(),x,y);}
		}
		y+=40;
		if(tank[0]!=null)g.drawString("Tank2_D_F:"+tank[0].isDoubleFire(),x,y);
		
	}
	//Paint方法 
	public void paint(Graphics g){
		g.fillRect(0, 0, 700, 600);
		g.setColor(Color.orange);
		g.drawRect(0, 0, 500, 500);
		paintWall(g);
		paintTank(g);
		paintSoilWall(g);
		paintGrass(g);
		paintWater(g);
		paintBullet(g);
		paintTankInfo(g);
	}
	//开始方法
	private void startAction(){
		tank[0]=new MyTank(23,48);
		tank[1]=new MyTank(27,48);
		tank[2]=randomTank();
		tank[3]=randomTank();
		tank[4]=randomTank();
		tank[5]=randomTank();
		tank[6]=randomTank();
		tank[7]=randomTank();
		enemyTankMoveAction();
	}
	private Tank randomTank(){
		int x=index%6;
		index++;
		switch(x){
		case 0:return new EnemyTank2(25,1);
		case 1:return new EnemyTank(1,1);
		case 2:return new EnemyTank(48,1);
		case 3:return new EnemyTank(25,1);
		case 4:return new EnemyTank(1,1);
		case 5:return new EnemyTank(48,1);
		}
		return null;
	}
	public void enemyTankMoveAction(){
		Timer timer = new Timer();
		timer.schedule(new TimerTask(){
			public void run(){
				if(state==RUNNING){
					for(int i=2;i<=tank.length-1;i++){
						Random r=new Random();
						int x=r.nextInt(4);
						switch(x){
						case 0:moveLeftAction(tank[i]);break;
						case 1:moveRightAction(tank[i]);break;
						case 2:moveUpAction(tank[i]);break;
						case 3:moveDownAction(tank[i]);break;
						}
						if(tank[i] instanceof EnemyTank2){
							Random r2=new Random();
							int x2=r2.nextInt(4);
							switch(x2){
							case 0:moveLeftAction(tank[i]);moveLeftAction(tank[i]);break;
							case 1:moveRightAction(tank[i]);moveRightAction(tank[i]);break;
							case 2:moveUpAction(tank[i]);moveUpAction(tank[i]);break;
							case 3:moveDownAction(tank[i]);moveDownAction(tank[i]);break;
						}}
					}
				}
				repaint();
			}
		}, 0, 300);
		/*
		timer.schedule(new TimerTask(){
			public void run(){
				if(state==RUNNING){
						Random r=new Random();
						int x=r.nextInt(5);
						switch(x){
						case 0:moveLeftAction(tank[0]);break;
						case 1:moveRightAction(tank[0]);break;
						case 2:moveUpAction(tank[0]);break;
						case 3:moveDownAction(tank[0]);break;
						case 4:myTank2FireAction1(tank[0]);break;
						}
				}
				repaint();
			}
		}, 0, 400);*/
		timer.schedule(new TimerTask(){
			public void run(){
				if(state==RUNNING){
					enemyTankFireAction();
				}
				repaint();
			}
		}, 0, 1000);
	}
	public static void main(String[] args){
		   JFrame jf=new JFrame("七爷开发的坦克大战1.2版");
		   Test gamePanel=new Test();
			jf.add(gamePanel);
			jf.setBounds(100, 100, 700, 600);
			jf.setAlwaysOnTop(true);
			jf.setLocationRelativeTo(null);
			jf.setVisible(true);
			jf.setResizable(false);
			jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			jf.setIconImage(new ImageIcon(Test.class.getResource("biaotitupian.png")).getImage());
			gamePanel.startAction();		
		}
}
