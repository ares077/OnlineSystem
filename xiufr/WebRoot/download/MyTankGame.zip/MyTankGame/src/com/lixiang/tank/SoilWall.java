package com.lixiang.tank;

public class SoilWall extends Cell{
	public SoilWall(int h,int s) {
		super(h,s);
	}
}
