package com.lixiang.tank;

public class Bullet extends Cell{
	public Bullet(int h,int s) {
		super(h,s);
	}
}