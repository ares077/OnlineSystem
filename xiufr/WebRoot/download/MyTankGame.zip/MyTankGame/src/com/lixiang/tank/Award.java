package com.lixiang.tank;

public interface Award {
	int getType();
}
