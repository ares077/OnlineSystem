package com.lixiang.tank;

public class Water extends Cell{
	public Water(int h,int s) {
		super(h,s);
	}

}
