package com.lixiang.tank;

public interface Enemy {
	int getScore();

}
